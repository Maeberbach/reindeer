/* Reindeer: Registry client.
   Guided, one-decision-per-screen capture. Cropping happens here on a canvas
   so the server needs no image library and raw source photos are never kept. */

/* Where the server lives.

   Served by the app's own Express process, this is empty and every request
   below stays a plain relative path, exactly as before. When the client is
   hosted separately from the server (a preview deployment), the placeholder
   is rewritten at deploy time and the same paths are routed through to it.
   Nothing about local behaviour changes. */
const API = '__PORT_3210__'.startsWith('__') ? '' : '__PORT_3210__';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const api = async (url, opts = {}) => {
  const res = await fetch(API + url, opts);
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `Request failed (${res.status})`);
  return res.headers.get('content-type')?.includes('json') ? res.json() : res;
};
const toast = (msg, bad = false) => {
  const t = $('#toast');
  t.textContent = msg; t.className = `toast${bad ? ' bad' : ''}`; t.hidden = false;
  clearTimeout(t._h); t._h = setTimeout(() => { t.hidden = true; }, 3200);
};
const money = (c) => (c == null ? '' : `$${(c / 100).toLocaleString('en-US')}`);

let registry = { rooms: [], categories: [] };
let history = [];

// ------------------------------------------------------- duplicates (offered)
/**
 * Mention possible duplicates once, in plain language, and let the owner walk
 * away from it.
 *
 * The registry never compels a duplicate review. Getting things documented is
 * the whole point, and an owner halfway through a room should not be handed a
 * chore. Three honest choices: look now, look later, or leave it to the person
 * settling the estate — Reindeer: FairPlay runs the same check and shows it
 * to the personal representative.
 */
/*
 * While walking a room, duplicate warnings are counted quietly instead of shown.
 *
 * Keeping eight things out of one recording would otherwise raise the panel
 * eight times, each one covering the screen and standing between the owner and
 * the next room. Duplicates are never urgent here — the whole point of this app
 * is that a thing gets written down — so they are tallied and mentioned once, in
 * a sentence, when the owner comes back out of the room.
 */
let inRoomNaming = false;
let roomDupCount = 0;

function offerDuplicateCheck(count) {
  if (inRoomNaming) {
    roomDupCount += count;
    toast('Saved.');
    return;
  }
  const box = $('#dupOffer');
  if (!box) {
    toast('Saved.');
    return;
  }
  $('#dupOfferText').textContent =
    `Saved. ${count === 1 ? 'One item' : `${count} items`} may already be on your list. ` +
    `You do not have to sort this out now.`;
  box.hidden = false;
  box.dataset.count = String(count);
}

// Both buttons are wired once, at load, because the panel is permanent markup.
document.addEventListener('DOMContentLoaded', () => {
  $('#dupLook')?.addEventListener('click', runDuplicateCheck);
  // "Not now" is a complete answer. Nothing is queued, nothing is remembered as
  // owed, nothing is lost — the items are already saved.
  $('#dupLater')?.addEventListener('click', () => {
    $('#dupOffer').hidden = true;
    toast('Saved. Left as it is.');
  });
  $('#dupCheckBtn')?.addEventListener('click', runDuplicateCheck);
});

async function runDuplicateCheck() {
  $('#dupOffer').hidden = true;
  try {
    const { groups } = await api('/api/duplicates/scan');
    if (!groups.length) {
      toast('Nothing looks like a duplicate.');
      return;
    }
    go('list');
    toast(`${groups.length} to look at. They are marked in your list.`);
  } catch {
    toast('Could not check just now. Nothing was lost.', true);
  }
}

// ---------------------------------------------------------------- navigation
// The flow is keyed by name, never by position, so a step can be added or
// retired without silently rewiring the one after it.
/**
 * The short path is the whole point.
 *
 * An unrecorded item helps nobody, so the questions that must be answered to
 * get one onto the list are the only ones asked by default: a photograph, a
 * name, and who it is meant for. Naming the room, the maker, the story and the
 * category all make the record better, and none of them make it exist, so they
 * wait behind one optional detour rather than standing between the owner and a
 * saved item.
 *
 * 'Worth' was retired: what a thing is worth matters when the estate is
 * settled, not while an owner is photographing a sideboard, so it is asked at
 * distribution instead. Its markup is kept and marked data-retired so the next
 * person can see it was a decision.
 */
const CORE_STEPS = ['Photo', 'Name', 'For whom', 'Save'];
const DETAIL_STEPS = ['Room', 'Maker', 'Story', 'Kind'];
const FULL_STEPS = ['Photo', 'Name', 'For whom', ...DETAIL_STEPS, 'Save'];

/*
 * The gifting walk is shorter than the ordinary one, and deliberately so.
 *
 * When an owner already knows a thing is meant for a particular person, the
 * person is the whole point and the object's name is not: the photograph
 * identifies it, and a trustee reading the sheet is looking at the picture. So
 * this path asks for a photograph and a name of a PERSON, and never asks the
 * owner to caption their own belongings. Whatever the camera recognised fills
 * the title line by itself; if it recognised nothing, the line says so plainly
 * and points at the photograph.
 */
const PROMISE_STEPS = ['Photo', 'For whom', 'Save'];
const NO_TITLE = 'Unnamed item — see photograph';

/** What goes on the title line when the owner was never asked for one. */
const effectiveTitle = () =>
  cap.title || $('#capTitle')?.value.trim() || cap.ai?.label || NO_TITLE;

/** The sequence in play right now. Starts short; the owner may lengthen it. */
let STEP_LABELS = CORE_STEPS.slice();

function go(name, opts = {}) {
  if (!opts.back) history.push(currentScreen());
  $$('.screen').forEach((s) => { s.hidden = s.dataset.screen !== name; });
  $('#backBtn').hidden = name === 'home' || name === 'welcome' || name === 'recipientwelcome';
  $('#homeBtn').hidden = name === 'home' || name === 'welcome' || name === 'recipientwelcome';
  $('#appTitle').textContent = {
    welcome: 'Reindeer: Registry', recipientwelcome: 'Welcome', whattoexpect: 'What to expect', quietgift: 'The quiet gift', whosdoing: "Who's doing this?", helptype: "Who's helping?", home: 'Reindeer: Registry', capture: 'Add an item', batch: 'Add several',
    list: 'My items', detail: 'Item', print: 'Print', handoff: 'Finishing up', confirmsend: 'Confirm',
    signing: 'Making it official', people: 'My people',
    walk: 'Room by room', room: 'This room', promise: 'What you already know',
    // The addendum \u2014 named recipients + memorandum + signed versions.
    gifts: 'Special gifts by name', giftperson: 'One person',
    giftsign: 'Confirm your choices', giftversions: 'Signed versions',
    // Slice B \u2014 memorandum writer. Uses the same tile label as the
    // old gifts screen because that tile now opens this new writer.
    memo: 'Specific gifts by name', memoentry: 'One gift',
    // Slice 4 \u2014 couple mode.
    householdlink: 'Send invite', helperinvite: 'Invite a helper',
    // Ship B \u2014 contested categories.
    contested: 'Things families find hardest to divide', reminders: 'Holiday reminders',
  }[name] ?? 'Reindeer: Registry';
  window.scrollTo(0, 0);
  if (name === 'walk') loadWalk();
  if (name === 'promise') renderPromise();
  // Landing on the menu ends the gifting walk, so "Add one item" is never
  // silently shortened by a mode the owner has already left behind.
  if (name === 'home') { promiseMode = false; renderResume(); refreshQueueBadge(); renderCounters(); renderPartnerCard(); }
  if (name === 'batch') { const bi = $('#batchIntake'); if (bi) bi.hidden = false; }
  if (name === 'list') loadList();
  if (name === 'signing') loadExecution();
  if (name === 'people') loadPeople();
  if (name === 'capture') renderPersonChips();
  if (name === 'handoff') { verifyRecord(); refreshFinishScreen(); }
  // The gifts family. Each mount refreshes its data so the roster/preview
  // reflect any items added or reassigned since the owner was last here.
  if (name === 'gifts') loadGifts();
  if (name === 'giftperson' && !opts.editing) resetGiftPerson();
  if (name === 'giftsign') loadGiftSign();
  if (name === 'giftversions') loadGiftVersions();
  // Slice B \u2014 the new memorandum writer. Each mount re-reads
  // /api/memorandum so entries, conflicts, and the version chip are
  // never stale relative to what the partner just did.
  if (name === 'memo') loadMemo();
  if (name === 'memoentry' && !opts.editing) resetMemoEntry();
  // Slice 4 \u2014 household-link screen. Refreshes its data on every mount
  // so link state stays fresh without an app-wide state store.
  if (name === 'householdlink') loadHouseholdLink();
  if (name === 'helperinvite') loadHelperInvite();
  // Ship B \u2014 contested-categories screen. Renders per-category cards
  // and re-fetches the participant's saved holiday picks each time.
  if (name === 'contested') { renderContestedCards(); }
  if (name === 'reminders') { loadReminderPicker(); }
}
const currentScreen = () => $$('.screen').find((s) => !s.hidden)?.dataset.screen ?? 'home';

$('#backBtn').onclick = () => go(history.pop() || 'home', { back: true });
$('#homeBtn').onclick = () => go('home');
// Event delegation for data-go buttons — works for static HTML AND
// dynamically-inserted buttons (e.g. "Back to home" in invite screens).
document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-go]');
  if (!btn) return;
  if (btn.dataset.go === 'capture') resetCapture();
  go(btn.dataset.go);
});

// Quick test — the "Start here" tile on the welcome screen. Takes a photo
// immediately as a low-friction entry point, then routes to onboarding.
let quickTestMode = false;
let recipientPracticeMode = false;
const qtb = $('#quickTestBtn');
if (qtb) qtb.onclick = () => { quickTestMode = true; resetCapture(); go('capture'); };

// Recipient welcome — invited partner does one practice item, then lands on
// the room walkthrough page to start helping with the real inventory.
const rsb = $('#recipientStartBtn');
if (rsb) rsb.onclick = () => { recipientPracticeMode = true; resetCapture(); go('capture'); };

// Onboarding — "Who's doing this?" flow
$('#onboardWithHelp')?.addEventListener('click', () => go('helptype'));
$('#onboardAssistant')?.addEventListener('click', () => go('helperinvite'));

// ------------------------------------------------------------ guided capture
let cap = null;
let step = 0;

function resetCapture() {
  cap = { file: null, dataUrl: null, title: '', maker: '', marks: '', story: '', valueCents: null, valueBasis: 'unknown',
          room: '', category: '', recipient: '', relationship: '', note: '', ai: null,
          // Owner-set "this matters" mark. Both are OFF by default — the owner
          // must actively tick the box, and reason chips only apply once the
          // box is on. See docs/decisions/2026-08-06-important-flag.md.
          important: false, importantFeeling: false, importantMoney: false };
  STEP_LABELS = (promiseMode ? PROMISE_STEPS : CORE_STEPS).slice();
  step = 0;
  ['#capTitle', '#capMaker', '#capMarks', '#capStory', '#capValue', '#capRecipient', '#capRelationship', '#capOwnerNote', '#capRoomOther']
    .forEach((s) => { $(s).value = ''; });
  $('#capValueBasis').value = 'unknown';
  $('#capPreview').hidden = true; $('#aiNote').hidden = true; $('#capRoomOther').hidden = true;
  $$('#roomChips .chip, #catChips .chip').forEach((c) => c.setAttribute('aria-pressed', 'false'));
  // Reset the Important control on the review step.
  $('#capImportant').checked = false;
  $('#capImportantChips').hidden = true;
  $$('#capImportantChips .chip').forEach((c) => c.setAttribute('aria-pressed', 'false'));
  renderStep();
}

/*
 * The owner-set Important flag lives on the review step. Wired here rather
 * than at the top of the module because #capImportant only exists inside the
 * capture screen. The reason chips reveal only when the box is ticked; toggling
 * the box back off clears the chips so an unflagged item never carries a
 * reason. Whether the resulting reason serializes to 'feeling', 'money',
 * 'both', or '' is decided at save time in reasonFromCap().
 */
function wireImportantControl() {
  const box = $('#capImportant');
  const chipsWrap = $('#capImportantChips');
  if (!box || !chipsWrap) return;
  box.onchange = () => {
    cap.important = box.checked;
    chipsWrap.hidden = !box.checked;
    if (!box.checked) {
      cap.importantFeeling = false;
      cap.importantMoney = false;
      $$('#capImportantChips .chip').forEach((c) => c.setAttribute('aria-pressed', 'false'));
    }
  };
  $$('#capImportantChips .chip').forEach((chip) => {
    chip.onclick = () => {
      const now = chip.getAttribute('aria-pressed') !== 'true';
      chip.setAttribute('aria-pressed', String(now));
      const key = chip.dataset.reason === 'feeling' ? 'importantFeeling' : 'importantMoney';
      cap[key] = now;
    };
  });
}
wireImportantControl();

// Serializes the owner's chip selection to the four allowed backend values.
// Kept as one small function so the rule lives in exactly one place: reason is
// only meaningful on a flagged item, and both-off is not "unflagged", it is
// "flagged with no stated reason".
function reasonFromCap(c) {
  if (!c.important) return '';
  if (c.importantFeeling && c.importantMoney) return 'both';
  if (c.importantFeeling) return 'feeling';
  if (c.importantMoney) return 'money';
  return '';
}

function renderStep() {
  const here = STEP_LABELS[step];
  $$('.step').forEach((s) => { s.hidden = s.dataset.stepname !== here; });
  $('#stepDots').innerHTML = STEP_LABELS.map((_, i) => `<span class="dot${i <= step ? ' on' : ''}"></span>`).join('');
  $('#whereAmI').textContent = `Step ${step + 1} of ${STEP_LABELS.length} — ${STEP_LABELS[step]}`;
  $('#stepBack').textContent = step === 0 ? 'Cancel' : 'Back';
  $('#stepNext').textContent = step === STEP_LABELS.length - 1 ? 'Save item' : 'Next';
  if (step === STEP_LABELS.length - 1) renderSummary();
  // The recipient step is where the roster earns its keep.
  if (STEP_LABELS[step] === 'For whom') {
    renderPersonChips();
    // The "Add to my special gifts" block only shows once a name is
    // entered/picked. Re-run visibility on every step render so back
    // navigation and edits keep the block correct.
    if (typeof updateGiftBlockVisibility === 'function') updateGiftBlockVisibility();
  }
}

/**
 * Lengthen the walk to include the optional questions.
 *
 * Anything already answered is kept — the owner is being offered more to say,
 * never asked to repeat themselves — and they land on the first of the extra
 * questions rather than back at the beginning.
 */
function addMoreDetail() {
  STEP_LABELS = FULL_STEPS.slice();
  step = STEP_LABELS.indexOf(DETAIL_STEPS[0]);
  renderStep();
}

$('#capMoreDetail').onclick = addMoreDetail;
$('#stepBack').onclick = () => { if (step === 0) return go(promiseMode ? 'promise' : 'home'); step--; renderStep(); };
$('#stepNext').onclick = async () => {
  const here = STEP_LABELS[step];
  if (here === 'Photo' && !cap.dataUrl) return toast('Please take a photo first.', true);
  if (here === 'Name') {
    cap.title = $('#capTitle').value.trim();
    if (!cap.title) return toast('Please give the item a short name.', true);
  }
  if (here === 'Maker') {
    cap.maker = $('#capMaker').value.trim();
    cap.marks = $('#capMarks').value.trim();
  }
  if (here === 'Story') cap.story = $('#capStory').value.trim();
  if (here === 'Room' && $('#capRoomOther').value.trim()) {
    cap.room = $('#capRoomOther').value.trim();
    // Keep it as a choice for next time rather than making them retype it.
    rememberTypedRoom(cap.room);
  }
  if (here === 'For whom') {
    // Only in promise mode is a name insisted upon, because a promise without a
    // person is not a promise. Everywhere else blank stays perfectly valid: an
    // owner must never be nudged into naming someone they have not chosen, or
    // the printed record stops being evidence of their wishes.
    if (promiseMode && !$('#capRecipient').value.trim()) {
      return toast('This one is for someone in particular — please put in their name. '
        + 'If you are not sure, press Back and add it as an ordinary item instead.', true);
    }
    cap.recipient = $('#capRecipient').value.trim();
    cap.relationship = $('#capRelationship').value.trim();
    cap.note = $('#capOwnerNote').value.trim();
    // The gift block \u2014 only meaningful when a name is present. Persisting
    // the toggle here lets the save handler pick it up after the item POST.
    const makeGiftEl = $('#capMakeGift');
    cap.makeGift = !!(cap.recipient && makeGiftEl && makeGiftEl.checked);
  }
  if (step === STEP_LABELS.length - 1) return saveItem();
  step++; renderStep();
};

$('#capPhoto').onchange = async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  cap.file = f;
  cap.dataUrl = await downscale(f, 1600);
  $('#capPreview').src = cap.dataUrl; $('#capPreview').hidden = false;

  // Recognition can take most of a minute. Saying so, on the screen and not in
  // a toast that vanishes, is the difference between waiting and concluding the
  // app is broken. The Next button is never blocked while this runs: the photo
  // is already safe, and typing the name by hand is always allowed.
  // Looked up fresh on every write, never held onto. Moving between steps can
  // rebuild this part of the screen, and a reference captured before the wait
  // would end up pointing at a discarded element — the answer would arrive and
  // be written somewhere nobody can see it. Since this very message invites the
  // owner to carry on while it thinks, that is exactly what would happen.
  const setNote = (html) => {
    const el = $('#aiNote');
    if (!el) return;
    el.hidden = false;
    el.innerHTML = html;
  };
  setNote('Looking at the photo… this can take up to a minute. '
    + 'You do not have to wait — carry on and type the name yourself if you prefer.');

  const giveUp = new AbortController();
  const timer = setTimeout(() => giveUp.abort(), 75000);
  try {
    const { detections, vision_mode } = await api('/api/intake/detect', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      signal: giveUp.signal,
      body: JSON.stringify({ images: [{ data_url: cap.dataUrl, frame_index: 0 }] }),
    });
    // A stand-in model must not be dressed up as a real one. When no vision
    // service is configured the suggestion is meaningless, so say nothing
    // rather than putting an invented name in the person's own record.
    if (vision_mode === 'mock') {
      cap.ai = null;
      setNote('<b>Photo saved.</b> Automatic recognition is not switched on yet, '
        + 'so please type what this is. Nothing has been guessed for you.');
      return;
    }
    const best = detections.sort((a, b) => b.confidence - a.confidence)[0];
    if (best) {
      cap.ai = best;
      // Only fill the box if the owner has not already typed their own name for
      // it while waiting. Their words outrank the machine's, always.
      const box = $('#capTitle');
      if (box && !box.value.trim()) box.value = best.label;
      setNote(`This looks like: ${escapeHtml(best.label)}${best.category_hint ? ` (${escapeHtml(best.category_hint)})` : ''}. Change it if that is not right.`);
      if (best.category_hint) cap.category = best.category_hint;
    } else {
      setNote('<b>Photo saved.</b> Nothing was recognised in it, so please type what this is.');
    }
  } catch {
    // Recognition is a convenience and never a blocker — but failing in silence
    // leaves the owner staring at an empty box wondering what went wrong. Say
    // plainly that the photo is safe and that typing the name is all that is
    // needed. Never invent a name to fill the gap.
    cap.ai = null;
    setNote('<b>Photo saved.</b> Automatic recognition is not answering just now, '
      + 'so please type what this is. Nothing has been lost and nothing has been guessed for you.');
  } finally {
    clearTimeout(timer);
  }
};

/* ------------------------------------------------------------------ */
/* Money entered by hand or by voice.                                  */
/*                                                                     */
/* Speech recognition is inconsistent about numbers: "four hundred     */
/* fifty dollars" may come back as "450", "$450", or the words         */
/* themselves. All three have to work, or the person concludes the     */
/* microphone is broken and stops trusting it.                         */
/* ------------------------------------------------------------------ */
const NUM_WORDS = {
  zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9,
  ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16,
  seventeen: 17, eighteen: 18, nineteen: 19, twenty: 20, thirty: 30, forty: 40, fourty: 40,
  fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90,
};
const NUM_SCALES = { hundred: 100, thousand: 1000, million: 1000000 };

function wordsToNumber(text) {
  const tokens = text.toLowerCase().replace(/-/g, ' ').split(/\s+/).filter(Boolean);
  let total = 0, current = 0, saw = false;
  for (const t of tokens) {
    if (t === 'and') continue;
    if (t in NUM_WORDS) { current += NUM_WORDS[t]; saw = true; continue; }
    if (t in NUM_SCALES) {
      const scale = NUM_SCALES[t];
      if (scale === 100) current = (current || 1) * 100;
      else { total += (current || 1) * scale; current = 0; }
      saw = true;
      continue;
    }
    return null; // an unexpected word — don't guess
  }
  if (!saw) return null;
  return total + current;
}

/** Returns whole cents, or null when the text is not a usable amount. */
function parseMoneyToCents(raw) {
  if (raw == null) return null;
  let t = String(raw).toLowerCase().trim();
  if (!t) return null;
  // Commas and currency symbols are removed outright, not turned into spaces:
  // "1,250.00" must stay one number rather than becoming "1 250.00".
  t = t.replace(/\b(dollars?|bucks|usd|about|around|roughly|maybe|worth)\b/g, ' ')
       .replace(/[$,]/g, '')
       .replace(/\s+/g, ' ')
       .trim();
  if (!t) return null;

  const digits = t.match(/^(\d+(?:\.\d{1,2})?)$/);
  if (digits) return Math.round(parseFloat(digits[1]) * 100);

  // "1200 50" from "twelve hundred and fifty" is ambiguous; require plain words.
  const asWords = wordsToNumber(t);
  if (asWords !== null && Number.isFinite(asWords)) return Math.round(asWords * 100);
  return null;
}

/* ------------------------------------------------------------------ */
/* Voice input, available on every field that takes free text.         */
/* Previously only the story box had a microphone, so anything spoken  */
/* about the maker or the value had nowhere to land.                   */
/* ------------------------------------------------------------------ */
function startDictation(targetId, btn) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return toast('This device cannot listen. Please type instead.', true);
  const el = $('#' + targetId);
  const r = new SR();
  r.lang = 'en-US';
  r.interimResults = false;
  const original = btn.textContent;
  btn.textContent = '● Listening — tap when finished';
  btn.classList.add('listening');
  const restore = () => { btn.textContent = original; btn.classList.remove('listening'); };

  r.onresult = (e) => {
    const heard = e.results[0][0].transcript.trim();
    if (targetId === 'capValue') {
      const cents = parseMoneyToCents(heard);
      if (cents === null) {
        toast(`Heard "${heard}", which is not an amount. Please type it.`, true);
        return;
      }
      el.value = (cents / 100).toFixed(2).replace(/\.00$/, '');
      toast(`Recorded $${el.value}.`);
      return;
    }
    el.value += (el.value ? ' ' : '') + heard;
  };
  r.onerror = () => { restore(); toast('Could not hear that. Please type instead.', true); };
  r.onend = restore;
  r.start();
  toast('Listening…');
}

$$('[data-mic]').forEach((btn) => {
  btn.onclick = () => startDictation(btn.dataset.mic, btn);
});

/** "$1,250" rather than "$1250" — easier to read at a glance, and harder to misread by a factor of ten. */
function fmtMoney(cents) {
  const n = cents / 100;
  const whole = Number.isInteger(n);
  return '$' + n.toLocaleString('en-US', {
    minimumFractionDigits: whole ? 0 : 2,
    maximumFractionDigits: 2,
  });
}

const BASIS_WORDS = {
  unknown: 'a guess',
  owner_estimate: 'your own estimate',
  appraisal: 'a written appraisal',
  receipt: 'a receipt',
  comparable_sale: 'a similar one you saw sell',
  insurance: 'your insurance listing',
};

function renderSummary() {
  const onFullPath = STEP_LABELS.length === FULL_STEPS.length;
  const row = (k, v) => `<div><b>${k}:</b> ${v || '<span style="color:#8a857c">not given</span>'}</div>`;
  $('#capSummary').innerHTML = `
    ${cap.dataUrl ? `<img src="${cap.dataUrl}" class="preview" alt="">` : ''}
    ${row('Name', escapeHtml(effectiveTitle()))}${row('Intended for', cap.recipient)}
    ${cap.recipient ? '<div style="color:#55504a;font-size:16px">Recorded as a wish, not a legal instruction.</div>' : ''}
    ${onFullPath ? `${row('Room', cap.room)}${row('Maker or artist', cap.maker)}${row('Marks', cap.marks)}
         ${row('Story', cap.story)}${row('Kind', cap.category)}` : ''}`;

  // Offered, never pressed. The button disappears once taken so the summary
  // does not keep asking for something the owner has already been given.
  $('#capMoreDetail').hidden = onFullPath;
  $('#capMoreDetailNote').hidden = onFullPath;
}

/**
 * Identifiers are things a person can point to on the object: a maker's name,
 * a signature, a stamped number. Only what the owner actually told us goes in
 * here — nothing inferred.
 */
function buildIdentifiers() {
  const out = {};
  if (cap.maker) out.maker = cap.maker;
  if (cap.marks) out.marks = cap.marks;
  return out;
}

async function saveItem() {
  try {
    const item = await api('/api/items', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        title: effectiveTitle(), story: cap.story,
        room_name: cap.room || null, category_name: cap.category || null,
        review_state: 'kept',
        // The value on an estate record is the OWNER'S, never the camera's.
        // This app previously saved the vision model's guess as though the
        // owner had stated it — a fabricated brand and dollar figure stamped
        // with a confidence score. On an inventory families rely on to divide
        // property, that is not a rough edge, it is a false record.
        value_basis: cap.valueCents != null ? cap.valueBasis : 'unknown',
        value_estimate_cents: cap.valueCents,
        // Owner-set Important mark. The API validates the reason enum and
        // coerces it back to '' if the box was left off, so a stale form
        // cannot attach a reason to an unflagged item.
        owner_high_value: cap.important === true,
        owner_high_value_reason: reasonFromCap(cap),
        ai_confidence: cap.ai?.confidence ?? null,
        identifiers: buildIdentifiers(),
        recipient_hint: cap.recipient
          ? { recipient_name: cap.recipient, relationship: cap.relationship, owner_note: cap.note }
          : null,
      }),
    });
    if (cap.dataUrl) await uploadPhoto(item.item_id, cap.dataUrl);
    // A name typed here joins the roster, so the next item is one tap. The
    // save must not fail because the address book did, hence the catch.
    if (cap.recipient) {
      try { await addPerson(cap.recipient, cap.relationship, 'from_item'); } catch { /* not worth stopping for */ }
    }
    // Auto-populate the addendum roster from capture. If the owner ticked
    // "Add this to my special gifts", find-or-create an heir with this
    // name and link the item to it. Never a blocker for the save itself.
    if (cap.makeGift && cap.recipient) {
      try { await assignItemToNamedRecipient(item.item_id, cap.recipient, cap.relationship); }
      catch (e) { console.warn('gift assignment skipped:', e.message); }
    }
    toast('Saved. You can change it any time.');
    refreshCount();
    resetCapture();
    // In promise mode the owner is in the middle of emptying a list they already
    // carry in their head. Dropping them back on the menu after each one breaks
    // that thread; asking "anything else you already know?" keeps it.
    if (promiseMode) { promiseKept += 1; return go('promise'); }
    if (quickTestMode) { quickTestMode = false; return go('whosdoing'); }
    if (recipientPracticeMode) { recipientPracticeMode = false; return go('walk'); }
    go('home');
  } catch (e) { toast(e.message, true); }
}

async function uploadPhoto(itemId, dataUrl, bbox = null) {
  const blob = await (await fetch(dataUrl)).blob();
  const q = bbox ? `?bbox=${encodeURIComponent(JSON.stringify(bbox))}` : '';
  await fetch(`${API}/api/items/${itemId}/photos${q}`, { method: 'POST', headers: { 'content-type': blob.type || 'image/jpeg' }, body: blob });
}

// ------------------------------------------------------------------- batch
// Two lanes arrive here and then share one path. Photos become frames; a video
// becomes frames too. Everything after that is identical, which is why the
// walkthrough needed no new endpoint — the detect route already accepts frames
// and already groups the same object seen from several angles.
let batchFiles = [];
const MAX_FRAMES = 10;

function showThumbs() {
  const thumbs = $('#batchThumbs'); thumbs.innerHTML = '';
  for (const f of batchFiles) { const img = new Image(); img.src = f._dataUrl; thumbs.append(img); }
  $('#batchGo').disabled = !batchFiles.length;
  $('#batchGo').textContent = batchFiles.length
    ? `Find items in these ${batchFiles.length} pictures`
    : 'Find items in these';
}

$('#batchPhotos').onchange = async (e) => {
  batchFiles = [];
  for (const f of [...e.target.files].slice(0, MAX_FRAMES)) {
    f._dataUrl = await downscale(f, 1600);
    batchFiles.push(f);
  }
  showThumbs();
};

/**
 * Pull still frames out of a video in the browser.
 *
 * Deliberately forgiving. Frame seeking is unreliable on older phones, so every
 * failure mode ends with the owner still able to continue: if we get some frames
 * we use them, and if we get none we say so plainly and point at the photo lane
 * rather than showing an error and stopping.
 */
async function framesFromVideo(file, want = 8) {
  const v = document.createElement('video');
  v.muted = true; v.playsInline = true; v.preload = 'auto';
  v.src = URL.createObjectURL(file);
  try {
    await new Promise((res, rej) => {
      v.onloadedmetadata = res;
      v.onerror = () => rej(new Error('unreadable'));
      setTimeout(() => rej(new Error('timeout')), 15000);
    });
    const dur = Number.isFinite(v.duration) && v.duration > 0 ? v.duration : 0;
    if (!dur) return { frames: [], duration_ms: null };

    // Skip the first and last moments — those are usually a hand or a doorway.
    const times = Array.from({ length: want }, (_, i) => dur * ((i + 0.5) / want));
    const canvas = document.createElement('canvas');
    const frames = [];
    for (const t of times) {
      const ok = await new Promise((res) => {
        let done = false;
        const finish = (val) => { if (!done) { done = true; res(val); } };
        v.onseeked = () => finish(true);
        setTimeout(() => finish(false), 4000);
        try { v.currentTime = t; } catch { finish(false); }
      });
      if (!ok || !v.videoWidth) continue;
      const scale = Math.min(1, 1600 / Math.max(v.videoWidth, v.videoHeight));
      canvas.width = Math.round(v.videoWidth * scale);
      canvas.height = Math.round(v.videoHeight * scale);
      canvas.getContext('2d').drawImage(v, 0, 0, canvas.width, canvas.height);
      frames.push(canvas.toDataURL('image/jpeg', 0.82));
    }
    return { frames, duration_ms: Math.round(dur * 1000) };
  } catch {
    return { frames: [], duration_ms: null };
  } finally {
    URL.revokeObjectURL(v.src);
  }
}

$('#batchVideo').onchange = async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const state = $('#videoState');
  state.hidden = false;
  state.textContent = 'Looking through the recording… this can take a moment.';
  batchFiles = [];
  showThumbs();

  const { frames, duration_ms } = await framesFromVideo(file, MAX_FRAMES);

  if (!frames.length) {
    state.textContent = 'This phone could not read still pictures out of that video. '
      + 'Nothing was lost — please use “Choose photos” below instead.';
    return;
  }

  batchFiles = frames.map((dataUrl, i) => ({ _dataUrl: dataUrl, _frame: i }));
  showThumbs();
  state.textContent = `${frames.length} pictures taken from the recording. `
    + 'The recording itself is kept with your inventory.';

  // Keep the walkthrough itself. It is evidence of the room as it stood, and it
  // is worth more to a trustee than the frames we cut out of it.
  try {
    await fetch(`${API}/api/scope-media?title=${encodeURIComponent('Room walkthrough')}`
      + (duration_ms ? `&duration_ms=${duration_ms}` : ''), {
      method: 'POST', headers: { 'content-type': file.type || 'video/mp4' }, body: file,
    });
  } catch {
    state.textContent += ' (The recording itself could not be saved, but the pictures are here.)';
  }
};

/*
 * Render a set of guesses as keep-or-reject rows.
 *
 * Shared by the old "pick some photos" lane and the room-by-room naming pass, so
 * that keeping a thing behaves identically however the owner arrived at it.
 * Rows are appended into #namingRows when that container exists, which lets the
 * caller put its own explanation above them.
 */
function renderNamingRows(detections) {
  const host = $('#namingRows') ?? $('#batchResults');
  const rows = detections.map((d, i) => `
      <div class="card" data-det="${i}">
        <img src="${batchFiles[d.frame_index ?? 0]?._dataUrl ?? ''}" alt="">
        <div>
          <h3>${escapeHtml(d.label)}</h3>
          <div class="sub">${escapeHtml(d.category_hint ?? '')} ${d.quantity > 1 ? `· ${d.quantity} of them` : ''}</div>
          ${d.appraisal_suggested ? '<span class="badge hv">ASK SOMEONE ABOUT THIS ONE</span>' : ''}
          <div class="detrow">
            <button class="primary" data-keep="${i}">Keep</button>
            <button class="ghost" data-reject="${i}">Not a thing</button>
          </div>
        </div>
      </div>`).join('');
  if (host === $('#namingRows')) host.innerHTML = rows; else host.innerHTML += rows;

  $$('#batchResults [data-reject]').forEach((b) => { b.onclick = () => b.closest('.card').remove(); });
  $$('#batchResults [data-keep]').forEach((b) => {
    b.onclick = async () => {
      const d = detections[Number(b.dataset.keep)];
      const src = batchFiles[d.frame_index ?? 0];
      const crop = src ? await cropTo(src._dataUrl, d.bbox) : null;
      // Carry the room through, so a thing named during a walkthrough of the
      // dining room is filed in the dining room without being asked again.
      const { created, possible_duplicates } = await api('/api/intake/commit', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ detections: [{ ...d, crop_data_url: crop, room: room?.name ?? d.room ?? null }] }),
      });
      b.closest('.card').remove();
      refreshCount();
      // Getting things written down is the goal. A possible duplicate is
      // worth mentioning once, plainly, and is never allowed to block saving
      // or to demand a review here. Sorting duplicates out can happen now,
      // later, or in Reindeer: FairPlay — the owner's choice.
      if (possible_duplicates > 0) {
        offerDuplicateCheck(possible_duplicates);
      } else {
        toast('Saved.');
      }
      if (created.length) await api(`/api/items/${created[0]}/keep`, { method: 'POST' });
    };
  });
  if ($('#keepAll')) {
    $('#keepAll').onclick = async () => {
      $('#keepAll').disabled = true;
      const buttons = $$('#batchResults [data-keep]');
      for (const b of buttons) { await b.onclick(); }
      toast(`${buttons.length} things added to your list.`);
    };
  }
}

$('#batchGo').onclick = async () => {
  $('#batchGo').disabled = true;
  toast('Looking through the photos…');
  try {
    const { detections, vision_mode } = await api('/api/intake/detect', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ images: batchFiles.map((f, i) => ({ data_url: f._dataUrl, frame_index: i, media_id: `m${i}` })) }),
    });
    // The aim of this lane is a complete list, so keeping everything is the
    // easy path and rejecting is the exception. No value is shown here: bulk
    // intake records what a thing is, and what it is worth is decided later.
    $('#batchResults').innerHTML = (vision_mode === 'mock'
        ? `<div class="mockwarn"><p><strong>These are examples, not real findings.</strong>
             The picture-reading service is not switched on yet, so the names below were
             made up by the app rather than read from your photos.</p></div>`
        : '')
      + `<h2>Found ${detections.length} thing${detections.length === 1 ? '' : 's'}</h2>
      <p class="reassure">Keep whatever looks right. You are not naming anyone here —
        these are simply logged. Rejecting one changes nothing else.</p>
      ${detections.length > 1 ? '<button class="primary wide" id="keepAll">Keep all of these</button>' : ''}
      <div id="namingRows"></div>`;
    renderNamingRows(detections);
  } catch (e) { toast(e.message, true); }
  $('#batchGo').disabled = false;
};

// -------------------------------------------------------------------- list
async function loadList() {
  const params = new URLSearchParams();
  if ($('#q').value) params.set('search', $('#q').value);
  if ($('#filterRoom').value) params.set('room_id', $('#filterRoom').value);
  if ($('#filterState').value) params.set('review_state', $('#filterState').value);
  const { items } = await api(`/api/items?${params}`);
  $('#itemList').innerHTML = items.length ? items.map(cardHtml).join('')
    : '<p class="lede">Nothing here yet. Add your first item from the home screen.</p>';
  $$('#itemList .card').forEach((c) => { c.onclick = () => openDetail(c.dataset.id); });
}
['#q', '#filterRoom', '#filterState'].forEach((s) => { $(s).oninput = loadList; });

const cardHtml = (i) => `
  <button class="card" data-id="${i.item_id}">
    ${i.photos?.[0] ? `<img src="${API}/api/photos/${i.photos[0].photo_id}" alt="">` : '<div class="noimg">no photo</div>'}
    <div>
      <h3>${escapeHtml(i.title)}</h3>
      <div class="sub">${escapeHtml(i.room?.name ?? 'No room')} · ${escapeHtml(i.category?.name ?? 'No kind')}${i.quantity > 1 ? ` · ${i.quantity}` : ''}</div>
      ${i.review_state === 'draft' ? '<span class="badge draft">needs review</span>' : '<span class="badge kept">confirmed</span>'}
      ${i.recipient_hint?.recipient_name ? `<span class="badge who">for ${escapeHtml(i.recipient_hint.recipient_name)}</span>` : ''}
      ${i.owner_high_value ? '<span class="badge important">Important</span>' : ''}
    </div>
  </button>`;

async function openDetail(id) {
  const [i, conflictRes] = await Promise.all([
    api(`/api/items/${id}`),
    api('/api/memorandum/conflicts').catch(() => ({ conflicts: [], partner: null })),
  ]);
  // Step 5: if this item has a memorandum conflict, show a gold banner
  const myConflict = (conflictRes.conflicts || []).find((c) => c.item_id === id);
  const partnerName = conflictRes.partner?.display_name || 'your partner';
  // Pre-tick the two reason chips from what is already stored. 'both' ticks
  // both chips; 'feeling'/'money' ticks one; '' leaves them off. The chips
  // block only shows when the item is flagged.
  const isImportant = !!i.owner_high_value;
  const reason = i.owner_high_value_reason || '';
  const feelingOn = reason === 'feeling' || reason === 'both';
  const moneyOn = reason === 'money' || reason === 'both';
  // The owner-authored comment is rendered verbatim, right below the story.
  // The registry does not paraphrase, summarize, or interpret the owner's own
  // words — it prints them and shows them. Owners were previously unable to
  // read back their own comment between recording it and printing the sheet,
  // which broke the app's promise that the owner's authorship is preserved.
  // See docs/decisions/2026-08-06-important-comment.md.
  const commentBlock = i.owner_important_comment
    ? `<div class="owner-comment">
         <div class="owner-comment-lbl">In your own words</div>
         <div class="owner-comment-body">${escapeHtml(i.owner_important_comment)}</div>
       </div>`
    : '';
  const conflictBanner = myConflict
    ? `<div class="memo-note memo-note-conflict detail-conflict-banner">
         <p class="memo-conflict-heading">⚠ This item has a conflict</p>
         <p class="memo-conflict-text">You and ${escapeHtml(partnerName)} named different people for this item.
         Sort it out together before signing — or sign anyway; the paper tells the truth.</p>
       </div>`
    : '';
  $('#detailBody').innerHTML = `
    ${conflictBanner}
    <h2>${escapeHtml(i.title)}</h2>
    <div class="thumbs">${(i.photos ?? []).map((p) => `<img src="${API}/api/photos/${p.photo_id}" alt="">`).join('') || '<div class="noimg">no photo</div>'}</div>
    <div class="summary">
      <div><b>Room:</b> ${escapeHtml(i.room?.name ?? '—')}</div>
      <div><b>Kind:</b> ${escapeHtml(i.category?.name ?? '—')}</div>
      <div><b>How many:</b> ${i.quantity}</div>
      <div><b>Story:</b> ${escapeHtml(i.story) || '—'}</div>
      <div><b>Intended for:</b> ${escapeHtml(i.recipient_hint?.recipient_name ?? '—')}</div>
      <div><b>Recorded:</b> ${new Date(i.created_at).toLocaleDateString()}</div>
    </div>
    ${commentBlock}

    <!--
      Assign-to-heir row. The item may already carry an assigned_to_heir_id
      from the capture flow's "Add to my special gifts" toggle, or from
      the Special gifts screen. The picker shows every person on the
      Special-gifts roster; "Nobody in particular" unassigns.
    -->
    <div class="assign-block">
      <label class="important-lbl" for="detailHeir">This is a special gift for</label>
      <select id="detailHeir" class="bigin" data-item="${escapeHtml(i.item_id)}">
        <option value="">— nobody in particular —</option>
      </select>
      <p class="important-hint" id="detailHeirHint">
        Adds this item to your list of special gifting for that person. Use
        “Special gifts by name” to add somebody new to the list.
      </p>
    </div>

    <div class="important-block">
      <label class="important-check">
        <input type="checkbox" id="detailImportant"${isImportant ? ' checked' : ''}>
        <span class="important-lbl">This one is important</span>
      </label>
      <p class="important-hint">It matters, for whatever reason.</p>
      <div class="chips important-chips" id="detailImportantChips"${isImportant ? '' : ' hidden'}>
        <button type="button" class="chip" data-reason="feeling" aria-pressed="${feelingOn}">It means a lot</button>
        <button type="button" class="chip" data-reason="money" aria-pressed="${moneyOn}">It is worth money</button>
      </div>
    </div>

    <div class="detrow">
      <a class="primary" target="_blank" href="${API}/api/print/item/${i.item_id}?mark=true">Print this sheet</a>
      <button class="ghost" id="delBtn">Remove item</button>
    </div>`;

  // Wire the Important control on the detail screen. Each change PATCHes the
  // item so the mark survives without a save button — the owner ticks and
  // walks away, and the list card reflects it on next load.
  const patchImportant = async () => {
    const on = $('#detailImportant').checked;
    const feeling = $$('#detailImportantChips .chip').find((c) => c.dataset.reason === 'feeling').getAttribute('aria-pressed') === 'true';
    const money = $$('#detailImportantChips .chip').find((c) => c.dataset.reason === 'money').getAttribute('aria-pressed') === 'true';
    const reason = !on ? '' : (feeling && money ? 'both' : feeling ? 'feeling' : money ? 'money' : '');
    try {
      await api(`/api/items/${i.item_id}`, {
        method: 'PATCH', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ owner_high_value: on, owner_high_value_reason: reason }),
      });
    } catch (e) { toast(e.message, true); }
  };
  $('#detailImportant').onchange = () => {
    const on = $('#detailImportant').checked;
    $('#detailImportantChips').hidden = !on;
    if (!on) {
      $$('#detailImportantChips .chip').forEach((c) => c.setAttribute('aria-pressed', 'false'));
    }
    patchImportant();
  };
  $$('#detailImportantChips .chip').forEach((chip) => {
    chip.onclick = () => {
      const now = chip.getAttribute('aria-pressed') !== 'true';
      chip.setAttribute('aria-pressed', String(now));
      patchImportant();
    };
  });

  // Populate the assign-to-heir picker with the current Special-gifts
  // roster, mark the currently-assigned heir as selected, and PATCH
  // /api/items/:id/assign on change. Failures are non-fatal; the item
  // itself is unchanged.
  (async () => {
    try {
      const list = await api('/api/two-outputs/heirs');
      const heirs = list.heirs || [];
      const sel = $('#detailHeir');
      if (!sel) return;
      const current = i.assigned_to_heir_id || '';
      const optionHtml = heirs.map((h) => {
        const kind = h.recipient_type === 'named_recipient' ? ' (someone else by name)' : '';
        const rel = h.relationship ? ' \u2014 ' + h.relationship : '';
        return `<option value="${escapeHtml(h.heir_id)}"${h.heir_id === current ? ' selected' : ''}>${escapeHtml(h.name)}${escapeHtml(rel)}${escapeHtml(kind)}</option>`;
      }).join('');
      sel.innerHTML = '<option value="">\u2014 nobody in particular \u2014</option>' + optionHtml;

      // Soft nudge: if the item is Important and unassigned, tell the
      // owner they can (but do not have to) name somebody.
      if (isImportant && !current) {
        const hint = $('#detailHeirHint');
        if (hint) {
          hint.innerHTML = `<b>This item is marked Important.</b> You do not have to name someone \u2014
            but if you already have somebody in mind, choose them here and it goes onto your list of special gifting.`;
        }
      }

      sel.onchange = async () => {
        const heirId = sel.value || null;
        try {
          await api(`/api/items/${i.item_id}/assign`, {
            method: 'PATCH', headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ heir_id: heirId }),
          });
          toast(heirId ? 'Added to their list.' : 'Not for anybody in particular.');
        } catch (e) { toast(e.message, true); }
      };
    } catch { /* the roster is optional \u2014 detail must still open */ }
  })();

  $('#delBtn').onclick = async () => {
    if (!confirm(`Remove "${i.title}"? The removal is recorded in the history.`)) return;
    await api(`/api/items/${i.item_id}?reason=owner+removed`, { method: 'DELETE' });
    toast('Removed. The history keeps a record.'); refreshCount(); go('list', { back: true });
  };
  go('detail');
}

/* ------------------------------------------------------------------ */
/* Finishing up.                                                       */
/*                                                                     */
/* Sending the list to Reindeer: FairPlay used to sit on the home     */
/* screen as a headline action, which implied the family division was  */
/* the point of the app. It is not, and for most people it is months   */
/* or years away. It now sits here as one option among four, chosen    */
/* when the list is actually finished.                                 */
/* ------------------------------------------------------------------ */
const FINISH_OPTS = ['#optEmail', '#optPrint', '#optSave', '#optSigned', '#optFairChoice'];

async function refreshFinishScreen() {
  try {
    const { items } = await api('/api/items');
    const n = items.length;
    $('#finishCount').textContent = n
      ? `You have recorded ${n} item${n === 1 ? '' : 's'}. Choose as many as you like — you can come back and do the others later.`
      : 'You have not recorded anything yet. Add an item first.';
  } catch { /* the count is a nicety, not a requirement */ }
  updateFinishButton();
}

function updateFinishButton() {
  const chosen = FINISH_OPTS.filter((id) => $(id).checked);
  const btn = $('#finishGo');
  btn.disabled = chosen.length === 0;
  btn.textContent = chosen.length === 0
    ? 'Choose at least one'
    : chosen.length === 1 ? 'Do this one thing' : `Do these ${chosen.length} things`;
  $('#emailFields').hidden = !$('#optEmail').checked;
}

FINISH_OPTS.forEach((id) => { $(id).onchange = updateFinishButton; });

$('#finishGo').onclick = async () => {
  const wantEmail = $('#optEmail').checked;
  if (wantEmail) {
    const name = $('#trusteeName').value.trim();
    const email = $('#trusteeEmail').value.trim();
    if (!name) return toast('Please write your trustee\u2019s name.', true);
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return toast('That email address does not look right. Please check it.', true);
    // Emailing cannot be undone, so it gets its own plain confirmation screen.
    $('#confirmDetail').innerHTML =
      `<b>To:</b> ${escapeHtml(name)} &lt;${escapeHtml(email)}&gt;<br>`
      + '<b>What they receive:</b> your full list, every photo, every story, and your wishes about who gets what.';
    go('confirmsend');
    return;
  }
  await runFinishActions({ email: false });
};

$('#confirmSendCancel').onclick = () => go('handoff', { back: true });
$('#confirmSendGo').onclick = async () => { go('handoff', { back: true }); await runFinishActions({ email: true }); };

async function runFinishActions({ email }) {
  const done = [];
  const failed = [];
  const box = $('#finishResult');
  box.hidden = false;
  box.innerHTML = 'Working…';

  if (email) {
    try {
      const trustee = await api('/api/trustees', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: $('#trusteeName').value.trim(), email: $('#trusteeEmail').value.trim() }),
      });
      const prepared = await api('/api/delivery/prepare', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ trustee_ids: [trustee.trustee_id ?? trustee.id] }),
      });
      await api(`/api/delivery/${prepared.delivery_id ?? prepared.id}/send`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ confirmed: true }),
      });
      done.push(`Emailed to ${escapeHtml($('#trusteeName').value.trim())}`);
    } catch (e) {
      failed.push(`The email did not go out: ${escapeHtml(e.message)}`);
    }
  }

  if ($('#optPrint').checked) {
    window.open(`${API}/api/print/report`, '_blank');
    done.push('Opened the printable list');
  }

  if ($('#optSave').checked) {
    triggerDownload(`${API}/api/export/bundle`);
    setTimeout(() => triggerDownload(`${API}/api/export/csv`), 600);
    done.push('Saved a copy and a spreadsheet');
  }

  if ($('#optSigned').checked) {
    if (execution?.record) {
      window.open(`${API}/api/execution/scan/${execution.record.media_id}`, '_blank');
      done.push('Opened the photograph of your signed page — save it alongside the list when you send it');
    } else {
      failed.push('There is no signed page on file yet. Use <b>Make it official</b> on the home screen first.');
    }
  }

  if ($('#optFairChoice').checked) {
    triggerDownload(`${API}/api/export/bundle`);
    done.push('Downloaded the file for Reindeer: FairPlay — the captain opens it there, and every item lands in their review queue first');
  }

  box.innerHTML = [
    done.length ? `<b>Done:</b><ul>${done.map((d) => `<li>${d}</li>`).join('')}</ul>` : '',
    failed.length ? `<b>Not done:</b><ul>${failed.map((d) => `<li>${d}</li>`).join('')}</ul>` : '',
  ].join('');
  FINISH_OPTS.forEach((id) => { $(id).checked = false; });
  updateFinishButton();
}

function triggerDownload(url) {
  const a = document.createElement('a');
  a.href = url; a.download = '';
  document.body.append(a); a.click(); a.remove();
}

async function verifyRecord() {
  try {
    const v = await api('/api/audit/verify');
    $('#verifyBox').innerHTML = v.ok
      ? `<b>History intact.</b> ${v.count} recorded actions, none altered. This is what lets a printed list be trusted later.`
      : `<b>Warning:</b> the history could not be verified at entry ${v.brokenAt}.`;
  } catch { $('#verifyBox').textContent = ''; }
}

// -------------------------------------------------------------------- utils
function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/** Downscale on the client so uploads stay small on cellular. */
function downscale(file, max) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      resolve(c.toDataURL('image/jpeg', 0.85));
    };
    img.src = URL.createObjectURL(file);
  });
}

/** Crop to a normalized bbox with padding — the per-item thumbnail. */
function cropTo(dataUrl, bbox, pad = 0.06) {
  if (!bbox) return Promise.resolve(dataUrl);
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const [x, y, w, h] = bbox;
      const sx = Math.max(0, (x - pad)) * img.width;
      const sy = Math.max(0, (y - pad)) * img.height;
      const sw = Math.min(1 - x + pad, w + pad * 2) * img.width;
      const sh = Math.min(1 - y + pad, h + pad * 2) * img.height;
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(sw)); c.height = Math.max(1, Math.round(sh));
      c.getContext('2d').drawImage(img, sx, sy, sw, sh, 0, 0, c.width, c.height);
      resolve(c.toDataURL('image/jpeg', 0.85));
    };
    img.src = dataUrl;
  });
}

/* ------------------------------------------------------------------ signing

   The one part of this app that touches a document meant to have legal effect,
   and therefore the one part where the app's job is to say no. Electronic
   signature law carves wills out by name, and a memorandum of tangible personal
   property takes effect through the will that refers to it. So there is no
   signature control here and there never will be — it would look authoritative
   and fail at the only moment it was ever needed.

   What is left is worth having: print the page, sign it in ink, photograph the
   result, say where the paper went, say out loud that you meant it, and let a
   professional put their name to having seen it. */

let execution = null;
let signBlob = null;

async function loadExecution() {
  try {
    execution = await api('/api/execution');
  } catch { execution = null; return; }
  const rec = execution?.record;

  if (rec) {
    $('#signPreview').src = `${API}/api/execution/scan/${rec.media_id}`;
    $('#signPreview').hidden = false;
    if (rec.signed_on) $('#signDate').value = rec.signed_on;
    if (rec.original_location) $('#signPlace').value = rec.original_location;
    $('#stmtBox').hidden = false;
    if (rec.statement) {
      $('#stmtPlayer').src = `${API}/api/execution/statement/${rec.statement.media_id}`;
      $('#stmtPlayer').hidden = false;
      $('#stmtRecord').textContent = 'Record it again';
    }
    const box = $('#signResult');
    box.hidden = false;
    box.innerHTML = `<b>On file.</b> Your signed page was photographed on ${new Date(rec.captured_at).toLocaleDateString('en-US', { dateStyle: 'long' })}.`
      + (rec.original_location ? `<br>The original is kept: ${escapeHtml(rec.original_location)}` : '<br>Please say where you are keeping the signed original.');
  }

  renderAttestations();
  updateSignButton();
}

function updateSignButton() {
  const btn = $('#signSave');
  const has = !!signBlob;
  const already = !!execution?.record;
  btn.disabled = !has && !already;
  btn.textContent = has
    ? 'Save the signed page'
    : already ? 'Update where the original is kept' : 'Photograph the page first';
}

$('#signPrint').onclick = () => {
  window.open(`${API}/api/print/memorandum`, '_blank');
  toast('Print it, then sign it with a pen.');
};

$('#signScan').onchange = async (e) => {
  const f = e.target.files?.[0];
  if (!f) return;
  // A signature has to stay legible, so this is downscaled far less than an
  // item photograph would be.
  const dataUrl = await downscale(f, 2400);
  signBlob = await (await fetch(dataUrl)).blob();
  $('#signPreview').src = dataUrl;
  $('#signPreview').hidden = false;
  if (!$('#signDate').value) $('#signDate').value = new Date().toISOString().slice(0, 10);
  updateSignButton();
};

$('#signSave').onclick = async () => {
  const place = $('#signPlace').value.trim();
  const when = $('#signDate').value;
  const btn = $('#signSave');
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    if (signBlob) {
      const q = `?signed_on=${encodeURIComponent(when)}&original_location=${encodeURIComponent(place)}`;
      const res = await fetch(`${API}/api/execution/scan${q}`, {
        method: 'POST', headers: { 'content-type': signBlob.type || 'image/jpeg' }, body: signBlob,
      });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'The signed page could not be saved.');
      signBlob = null;
      toast('Your signed page is on file.');
    } else if (execution?.record) {
      await api(`/api/execution/${execution.record.media_id}`, {
        method: 'PATCH', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ original_location: place, signed_on: when }),
      });
      toast('Saved.');
    }
    await loadExecution();
  } catch (err) {
    toast(err.message, true);
    updateSignButton();
  }
};

// ---- the spoken statement
let recorder = null;
let chunks = [];

$('#stmtRecord').onclick = async () => {
  const btn = $('#stmtRecord');
  if (recorder && recorder.state === 'recording') { recorder.stop(); return; }
  if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
    return toast('This device will not let the app record sound.', true);
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    chunks = [];
    recorder = new MediaRecorder(stream);
    recorder.ondataavailable = (ev) => { if (ev.data.size) chunks.push(ev.data); };
    recorder.onstop = async () => {
      stream.getTracks().forEach((t) => t.stop());
      btn.classList.remove('listening');
      btn.textContent = 'Saving…';
      const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
      try {
        const res = await fetch(`${API}/api/execution/${execution.record.media_id}/statement`, {
          method: 'POST', headers: { 'content-type': blob.type }, body: blob,
        });
        if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'The recording could not be saved.');
        toast('Your statement is saved with the signed page.');
        await loadExecution();
      } catch (err) {
        toast(err.message, true);
        btn.textContent = 'Start recording';
      }
    };
    recorder.start();
    btn.classList.add('listening');
    btn.textContent = 'Recording — tap to stop';
  } catch {
    toast('The microphone could not be opened. Check the app is allowed to use it.', true);
  }
};

// ---- the professional's confirmation
$('#attestOpen').onclick = () => {
  const box = $('#attestFields');
  box.hidden = !box.hidden;
  $('#attestOpen').textContent = box.hidden ? 'Record a confirmation' : 'Never mind';
};

$('#attSave').onclick = async () => {
  if (!execution?.record) return toast('Photograph the signed page first.', true);
  const name = $('#attName').value.trim();
  if (!name) return toast('Please write their name.', true);
  try {
    await api(`/api/execution/${execution.record.media_id}/attest`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        name, role: $('#attRole').value, firm: $('#attFirm').value.trim(),
        email: $('#attEmail').value.trim(), holds: $('#attHolds').value,
      }),
    });
    ['#attName', '#attFirm', '#attEmail'].forEach((s) => { $(s).value = ''; });
    $('#attestFields').hidden = true;
    $('#attestOpen').textContent = 'Record a confirmation';
    toast('Confirmation recorded.');
    await loadExecution();
  } catch (err) { toast(err.message, true); }
};

const ROLE_WORDS = {
  trustee: 'Trustee', personal_representative: 'Trustee (also called personal representative)',
  executor: 'Trustee (also called executor)', attorney: 'Attorney', other: 'Confirmed by',
};
const HOLDS_WORDS = {
  holds_original: 'is holding the signed original',
  seen_original: 'has seen the signed original',
  copy_only: 'has received a copy only',
};

function renderAttestations() {
  const list = execution?.record?.attestations ?? [];
  const box = $('#attList');
  if (!list.length) { box.hidden = true; box.innerHTML = ''; return; }
  box.hidden = false;
  box.innerHTML = '<b>Confirmed by:</b><ul>' + list.map((a) => {
    const when = new Date(a.confirmed_at).toLocaleDateString('en-US', { dateStyle: 'long' });
    const who = [escapeHtml(a.name), a.firm ? `of ${escapeHtml(a.firm)}` : ''].filter(Boolean).join(' ');
    return `<li>${escapeHtml(ROLE_WORDS[a.role] || 'Confirmed by')} ${who} — ${escapeHtml(HOLDS_WORDS[a.holds] || '')}, on ${when}</li>`;
  }).join('') + '</ul>';
}

/* ------------------------------------------------------------------- people

   The names an owner is leaving things to.

   This was the single largest source of friction in the app. A recipient was a
   free-text box on every item, so somebody recording eighty belongings typed
   "Kathy" eighty times, and every slip — "Kathy M", "kathy", "my daughter
   Kathy" — became a separate heir by the time the file reached Legacy: Fair
   Choice. Now the name is said once and tapped thereafter.

   Two ways in, because people work differently. Some want to declare the cast
   before they start; others discover it as they walk the house. Both work, and
   a name typed on an item is quietly added to the roster so the two never
   drift apart. */

let people = [];

async function loadPeople() {
  try {
    const data = await api('/api/people');
    people = data.people ?? [];
    renderPeopleList();
    renderUnlisted(data.unlisted ?? []);
    updatePeopleTileHint();
  } catch { /* the roster is a convenience, never a blocker */ }
}

function updatePeopleTileHint() {
  const hint = $('#peopleTileHint');
  if (!hint) return;
  hint.textContent = people.length
    ? people.slice(0, 4).map((p) => p.name).join(', ') + (people.length > 4 ? `, and ${people.length - 4} more` : '')
    : 'The names you are leaving things to';
}

function renderPeopleList() {
  const box = $('#peopleList');
  if (!people.length) {
    box.innerHTML = '<p class="reassure" style="margin:0">Nobody on the list yet. Add the first person below, '
      + 'or just start recording items and type names as they come to you.</p>';
    return;
  }
  box.innerHTML = people.map((p) => `
    <div class="personrow" data-person="${escapeHtml(p.person_id)}">
      <div class="personwho">
        <span class="personname">${escapeHtml(p.name)}</span>
        ${p.relationship ? `<span class="personrel">${escapeHtml(p.relationship)}</span>` : ''}
      </div>
      <span class="personcount">${p.item_count ? `${p.item_count} item${p.item_count === 1 ? '' : 's'}` : 'nothing yet'}</span>
      <button class="personx" data-remove="${escapeHtml(p.person_id)}" aria-label="Remove ${escapeHtml(p.name)} from the list">Remove</button>
    </div>`).join('');

  $$('#peopleList [data-remove]').forEach((b) => {
    b.onclick = async () => {
      const person = people.find((p) => p.person_id === b.dataset.remove);
      // Irreversible-looking actions get asked about first, in plain words.
      if (!confirm(`Take ${person?.name ?? 'this person'} off your list?\n\nItems you have already recorded for them keep their name. Nothing you have written is deleted.`)) return;
      try {
        await api(`/api/people/${b.dataset.remove}`, { method: 'DELETE' });
        toast('Taken off the list. Your items are unchanged.');
        await loadPeople();
      } catch (e) { toast(e.message, true); }
    };
  });
}

function renderUnlisted(unlisted) {
  const box = $('#peopleUnlisted');
  if (!unlisted.length) { box.hidden = true; box.innerHTML = ''; return; }
  box.hidden = false;
  box.innerHTML = `<b>You have already named these people on your items.</b> Add them to your list so you can tap them next time.`
    + `<div class="chips" style="margin-top:12px">${unlisted.map((u) => `<button class="chip" data-adopt="${escapeHtml(u.name)}" data-rel="${escapeHtml(u.relationship)}">${escapeHtml(u.name)} <span class="chipn">${u.item_count}</span></button>`).join('')}</div>`
    + `<button class="ghost wide" id="adoptAll" style="margin-top:12px">Add all ${unlisted.length} of them</button>`;

  $$('#peopleUnlisted [data-adopt]').forEach((b) => {
    b.onclick = async () => {
      await addPerson(b.dataset.adopt, b.dataset.rel, 'from_item');
    };
  });
  $('#adoptAll').onclick = async () => {
    try {
      const res = await api('/api/people/bulk', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ people: unlisted.map((u) => ({ name: u.name, relationship: u.relationship, source: 'from_item' })) }),
      });
      toast(`Added ${res.added.length} ${res.added.length === 1 ? 'person' : 'people'}.`);
      await loadPeople();
    } catch (e) { toast(e.message, true); }
  };
}

async function addPerson(name, relationship, source = 'typed') {
  const clean = (name ?? '').trim();
  if (!clean) { toast('Please write their name first.', true); return null; }
  try {
    const person = await api('/api/people', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: clean, relationship: (relationship ?? '').trim(), source }),
    });
    await loadPeople();
    return person;
  } catch (e) { toast(e.message, true); return null; }
}

// Common relationships as one-tap chips. Typing "granddaughter" correctly on a
// phone keyboard is exactly the kind of small defeat that makes somebody put
// the app down.
const REL_SUGGESTIONS = ['daughter', 'son', 'wife', 'husband', 'sister', 'brother',
  'granddaughter', 'grandson', 'niece', 'nephew', 'friend', 'charity'];

function mountPeopleScreen() {
  $('#relChips').innerHTML = REL_SUGGESTIONS
    .map((r) => `<button class="chip" data-rel="${r}" aria-pressed="false">${r}</button>`).join('');
  $$('#relChips .chip').forEach((b) => {
    b.onclick = () => {
      $$('#relChips .chip').forEach((o) => o.setAttribute('aria-pressed', 'false'));
      b.setAttribute('aria-pressed', 'true');
      $('#personRel').value = b.dataset.rel;
    };
  });

  $('#personAdd').onclick = async () => {
    const person = await addPerson($('#personName').value, $('#personRel').value);
    if (!person) return;
    toast(person.created === false ? `${person.name} was already on your list.` : `${person.name} added.`);
    $('#personName').value = ''; $('#personRel').value = '';
    $$('#relChips .chip').forEach((o) => o.setAttribute('aria-pressed', 'false'));
    $('#personName').focus();
  };

  // Enter on the name field should add, not reload the page.
  $('#personName').onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); $('#personAdd').click(); } };
  $('#personRel').onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); $('#personAdd').click(); } };
}

/* ---- the "who is it for?" step of the capture flow ---- */

function renderPersonChips() {
  const box = $('#personChips');
  if (!box) return;
  if (!people.length) { box.innerHTML = ''; return; }
  const chosen = (cap.recipient ?? '').trim().toLowerCase();
  box.innerHTML = people.map((p) => `<button class="chip" data-pick="${escapeHtml(p.name)}" data-rel="${escapeHtml(p.relationship)}" aria-pressed="${p.name.toLowerCase() === chosen}">${escapeHtml(p.name)}${p.relationship ? ` <span class="chiprel">${escapeHtml(p.relationship)}</span>` : ''}</button>`).join('')
    + '<button class="chip" data-pick="" aria-pressed="false">Somebody else</button>';

  $$('#personChips .chip').forEach((b) => {
    b.onclick = () => {
      const name = b.dataset.pick;
      $('#capRecipient').value = name;
      $('#capRelationship').value = name ? (b.dataset.rel || '') : '';
      $$('#personChips .chip').forEach((o) => o.setAttribute('aria-pressed', 'false'));
      b.setAttribute('aria-pressed', 'true');
      if (!name) $('#capRecipient').focus();
      checkNewPerson();
    };
  });
  checkNewPerson();
}

/*
 * When a name is typed that is not on the roster yet, say so before the item
 * is saved rather than silently creating a near-duplicate heir. The name is
 * still accepted either way — this is a nudge, never a gate.
 */
function checkNewPerson() {
  const note = $('#newPersonNote');
  if (!note) return;
  const typed = $('#capRecipient').value.trim();
  // Keep the highlighted chip honest: if the box no longer says what the chip
  // says, nothing should look selected.
  $$('#personChips .chip').forEach((c) => {
    c.setAttribute('aria-pressed', String(!!c.dataset.pick && c.dataset.pick.toLowerCase() === typed.toLowerCase()));
  });
  const known = people.some((p) => p.name.toLowerCase() === typed.toLowerCase());
  if (!typed || known) { note.hidden = true; return; }
  const near = people.find((p) => p.name.toLowerCase().startsWith(typed.toLowerCase().slice(0, 3)) && typed.length >= 3);
  note.hidden = false;
  note.innerHTML = near
    ? `<b>${escapeHtml(typed)}</b> is new. Did you mean <b>${escapeHtml(near.name)}</b>? Two spellings of one person become two different people on the printed list.`
    : `<b>${escapeHtml(typed)}</b> is not on your list yet. They will be added to it when you save this item.`;
}

async function refreshCount() {
  const { items } = await api('/api/items');
  $('#countPill').textContent = `${items.length} item${items.length === 1 ? '' : 's'}`;
}

/* ------------------------------------------------------- what you already know
 *
 * The promise lane.
 *
 * Everything here exists to get one sentence out of the owner — "the clock goes
 * to Robert" — before the app has asked them for anything else. That sentence is
 * the whole product. A room is only a way of finding more of them.
 *
 * What this lane deliberately does NOT do: no streak, no countdown, no "most
 * people have finished by now", nothing withheld until a quota is met, and never
 * a suggested recipient. Pressure applied by an app to an elderly person is
 * attackable afterwards as undue influence, and any pressure that pushes toward
 * naming a person rather than toward writing things down would poison the very
 * document it was trying to produce. The only push here is the true one: what
 * happens to the things nobody is named for.
 */

let promiseMode = false;
let promiseKept = 0;

function renderPromise() {
  const first = promiseKept === 0;
  $('#promiseAsk').textContent = first
    ? 'Is there anything you already know should go to someone in particular?'
    : 'Anything else you already know?';
  $('#promiseWhy').textContent = first
    ? "A ring for your daughter. Your father's watch for your son. If a name comes to "
      + 'mind, start there. One photograph, one name, and it is written down.'
    : 'People usually remember two or three more once they start. Take them one at a time.';
  $('#promiseYes').textContent = first ? 'Yes — let me name one' : 'Yes — one more';
  $('#promiseNo').textContent = first ? 'Nothing comes to mind' : "That's everything I know";

  const tally = $('#promiseTally');
  tally.hidden = promiseKept === 0;
  if (promiseKept > 0) {
    tally.innerHTML = `<p><strong>${promiseKept === 1 ? 'One thing' : `${promiseKept} things`}</strong> `
      + 'now says who it is for. That is written down and it will print.</p>';
  }

  $('#promisePivot').hidden = true;
  $('#promiseYes').hidden = false;
  $('#promiseNo').hidden = false;
}

$('#promiseYes').onclick = () => {
  promiseMode = true;
  resetCapture();
  go('capture');
};

$('#promiseNo').onclick = async () => {
  $('#promiseYes').hidden = true;
  $('#promiseNo').hidden = true;
  $('#promisePivot').hidden = false;
  $('#promisePivotRest').textContent = await pivotSentence();
  $('#promisePivot').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
};

$('#promiseOnward').onclick = () => { promiseMode = false; promiseKept = 0; go('home'); };

/**
 * The consequence, said in the owner's own family's names where they are known.
 *
 * "Some items are unassigned" is a status. "Robert, Elena and Katherine will
 * decide it between them" is a picture, and a picture is what makes somebody
 * pick the phone back up. It is also simply true, which is why it is allowed.
 */
async function pivotSentence() {
  const generic = 'Everything else in the house, your family will have to work out between '
    + 'themselves. Writing those down is what stops that becoming an argument.';
  try {
    const { people = [] } = await api('/api/people');
    const names = people.filter((p) => !p.archived).map((p) => p.name).filter(Boolean);
    if (names.length < 2) return generic;
    // Three names is a picture. Six is a list, and a list reads as paperwork.
    const list = names.length === 2
      ? `${names[0]} and ${names[1]}`
      : names.length <= 3
        ? `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`
        : `${names.slice(0, 3).join(', ')} and the others`;
    return `Everything else in the house, ${list} will have to work out between themselves. `
      + 'Writing those down is what stops that becoming an argument.';
  } catch { return generic; }
}

/**
 * Partner invitation on Home. Shown only when the account is in solo mode
 * (no linked partner). Once linked, we hide the invite and show a small
 * quiet confirmation with the partner's name. This makes the couple flow
 * discoverable to owners who don't scroll to the quietrow at the bottom.
 *
 * Data source: /api/scope-summary returns { household_mode, partner? }.
 * Fail-silent: if the call errors, both elements stay hidden — no worse
 * than the app before this render function existed.
 */
async function renderPartnerCard() {
  const add = $('#homePartnerAdd');
  const linked = $('#homePartnerLinked');
  const nameSpan = $('#homePartnerName');
  if (!add || !linked) return;
  try {
    const s = await api('/api/scope-summary');
    if (s?.household_mode === 'couple') {
      add.hidden = true;
      linked.hidden = false;
      // scope-summary does not include the partner's display name; fetch it
      // from /api/household-link only when we already know we're in couple
      // mode. Fail-silent to a generic label if the second call misses.
      let partnerName = 'your partner';
      try {
        const hl = await api('/api/household-link');
        // household-link returns participants[]; pick the one that is not me.
        const others = (hl?.participants || []).filter((p) => !p.is_me);
        const other = others[0];
        partnerName = other?.display_name || other?.email || partnerName;
      } catch { /* keep generic label */ }
      if (nameSpan) nameSpan.textContent = partnerName;
    } else {
      add.hidden = false;
      linked.hidden = true;
    }
  } catch {
    add.hidden = true;
    linked.hidden = true;
  }
}

/**
 * Two counts on the menu, refreshed whenever the owner lands there.
 *
 * Never combined into a percentage — see the note in the markup.
 */
async function renderCounters() {
  let items = [];
  try { ({ items } = await api('/api/items')); } catch { return; }
  const box = $('#homeCounters');
  if (!items.length) { box.hidden = true; return; }

  // Step 5: fetch memorandum conflicts so the Home counter can show them.
  const conflictRes = await api('/api/memorandum/conflicts').catch(() => ({ conflicts: [] }));
  const conflictCount = (conflictRes.conflicts || []).length;
  const conflictBox = $('#homeConflictCounter');
  if (conflictBox) {
    if (conflictCount > 0) {
      conflictBox.hidden = false;
      $('#cntConflict').textContent = String(conflictCount);
    } else {
      conflictBox.hidden = true;
    }
  }

  const spoken = items.filter((i) => i.recipient_hint?.recipient_name).length;
  const open = items.length - spoken;
  box.hidden = false;
  $('#cntSpoken').textContent = String(spoken);
  $('#cntOpen').textContent = String(open);

  const note = $('#counterNote');
  if (open > 0) {
    note.hidden = false;
    // This line used to point at one of the owner's own possessions and say that
    // nobody was named for it. That is pressure to assign an heir to a specific
    // thing, which is not the app's business: an unnamed item is a finished,
    // correct record, and dividing those is exactly what FairPlay is for.
    // Persuasion here is only ever about getting the list DONE, never about who
    // gets what.
    note.textContent = open === 1
      ? 'One thing is written down with nobody named. That is perfectly normal — '
        + 'Reindeer: FairPlay can help your family divide anything left open.'
      : `${open} things are written down with nobody named. That is perfectly normal — `
        + 'Reindeer: FairPlay can help your family divide anything left open.';
  } else {
    note.hidden = true;
  }
}

/*
 * The kinds of thing on the capture screen.
 *
 * Shown, in order: the categories Registry seeds today, then anything the owner
 * has invented or pulled out of the dropdown. An inventory made before the
 * seeded list changed still holds its old names, and every item using one keeps
 * working — but those names are left off the buttons, because the point of a
 * short list is that it is short. They remain reachable in the item's own
 * screen and in every printout.
 */
function renderCatChips() {
  const starter = registry.starter_categories ?? [];
  const rank = new Map(starter.map((n, i) => [n.toLowerCase(), i]));
  const byName = new Map(registry.categories.map((c) => [c.name.toLowerCase(), c]));

  // Today's list first, in the order it is defined rather than by sort_order,
  // so the run of contested kinds reads top to bottom as intended.
  const seeded = starter.map((n) => byName.get(n.toLowerCase())).filter(Boolean);
  // Then the owner's own, and anything promoted out of the silent list.
  const theirs = registry.categories.filter((c) => !rank.has(c.name.toLowerCase())
    && (c.is_custom === 1 || c.sort_order === 500));

  const chip = (c) => `<button class="chip${c.is_custom ? ' chip-mine' : ''}" aria-pressed="false"`
    + ` data-cat="${escapeHtml(c.name)}">${escapeHtml(c.name)}</button>`;
  $('#catChips').innerHTML = [...seeded, ...theirs].map(chip).join('');

  $$('#catChips .chip').forEach((b) => {
    b.onclick = () => {
      $$('#catChips .chip').forEach((x) => x.setAttribute('aria-pressed', 'false'));
      b.setAttribute('aria-pressed', 'true');
      cap.category = b.dataset.cat;
    };
  });

  // Ship B \u2014 if the contested-categories screen pre-set cap.category
  // before jumping here, visually press the matching chip so the owner sees
  // it is already selected. If the chip is not on today's list yet (a
  // MORE_CATEGORIES entry), promote it now; addOfferedCategory selects it.
  if (cap && cap.category) {
    const match = $$('#catChips .chip').find((c) => c.dataset.cat === cap.category);
    if (match) match.setAttribute('aria-pressed', 'true');
    else if ((registry.more_categories ?? []).includes(cap.category)) {
      addOfferedCategory(cap.category);
    }
  }

  renderCatMore();
}

/*
 * The precise categories, kept silent until asked for.
 *
 * Every name here is a Reindeer: FairPlay category spelled exactly, so an
 * owner who would rather say "Coins & Stamps" than accept a coarse bucket can,
 * and that choice is treated as final downstream. It stays in a dropdown
 * because demanding that level of precision from everyone is how a person
 * stops recording their possessions altogether.
 */
function renderCatMore() {
  const wrap = $('#catMoreWrap');
  const sel = $('#catMore');
  if (!wrap || !sel) return;
  const left = registry.more_categories ?? [];
  wrap.hidden = left.length === 0;
  sel.innerHTML = '<option value="">Add another kind…</option>'
    + left.map((n) => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join('');
  sel.onchange = () => {
    const name = sel.value;
    sel.value = '';
    if (name) addOfferedCategory(name);
  };
}

/** Promote a category from the dropdown to a button, and select it. */
async function addOfferedCategory(name) {
  try {
    const cat = await api('/api/categories', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name, is_custom: false }),
    });
    registry.categories.push(cat);
    registry.more_categories = (registry.more_categories ?? [])
      .filter((n) => n.toLowerCase() !== cat.name.toLowerCase());
    renderCatChips();
    const made = $$('#catChips .chip').find((c) => c.dataset.cat === cat.name);
    if (made) made.setAttribute('aria-pressed', 'true');
    cap.category = cat.name;
    toast(`“${cat.name}” added to your list.`);
  } catch {
    // Offline. The name rides along with the item and the server creates the
    // category when it arrives, so nothing is lost by carrying on.
    cap.category = name;
  }
}

/*
 * Every room the owner has, not a curated handful.
 *
 * This used to filter the room list against a hardcoded set of seven "common"
 * names, which meant a room the owner added themselves — "Mother's Sewing
 * Room", "The Cabin" — was saved to the database correctly and then never shown
 * again. The owner had to retype it every single time, and reasonably concluded
 * the app had thrown it away. Their own room names are the ones they care most
 * about, so they are shown first and marked as theirs.
 */
function renderRoomChips() {
  const mine = registry.rooms.filter((r) => r.is_custom);
  const standard = registry.rooms.filter((r) => !r.is_custom && r.name !== 'Other');
  const other = registry.rooms.find((r) => r.name === 'Other');
  const chip = (r) => `<button class="chip${r.is_custom ? ' chip-mine' : ''}" aria-pressed="false"`
    + ` data-room="${escapeHtml(r.name)}">${escapeHtml(r.name)}</button>`;
  // "Somewhere else" always sits last: it is the escape hatch, not an option.
  $('#roomChips').innerHTML = [...mine, ...standard].map(chip).join('')
    + (other ? `<button class="chip chip-other" aria-pressed="false" data-room="Other">Somewhere else…</button>` : '');

  $$('#roomChips .chip').forEach((b) => {
    b.onclick = () => {
      $$('#roomChips .chip').forEach((x) => x.setAttribute('aria-pressed', 'false'));
      b.setAttribute('aria-pressed', 'true');
      cap.room = b.dataset.room;
      $('#capRoomOther').hidden = b.dataset.room !== 'Other';
      if (b.dataset.room === 'Other') $('#capRoomOther').focus();
    };
  });

  renderRoomMore();
}

/*
 * The rooms the owner does not have yet, kept out of the way.
 *
 * Registry seeds only the rooms nearly every home has. The rest live in this
 * dropdown so the buttons above stay a short, scannable list rather than a
 * wall of thirty. Choosing one promotes it to a permanent button, so the list
 * grows to match the house as the owner walks it, and never gets ahead of them.
 *
 * The whole control hides once every offered room has been taken, because a
 * dropdown holding nothing is a thing to read and be puzzled by.
 */
function renderRoomMore() {
  const wrap = $('#roomMoreWrap');
  const sel = $('#roomMore');
  if (!wrap || !sel) return;
  const left = registry.more_rooms ?? [];
  wrap.hidden = left.length === 0;
  sel.innerHTML = '<option value="">Add another room…</option>'
    + left.map((n) => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join('');
  sel.onchange = () => {
    const name = sel.value;
    sel.value = '';
    if (name) addOfferedRoom(name);
  };
}

/*
 * Promote a room from the dropdown to a button, and select it.
 *
 * Selecting it matters: the owner opened that list because they are standing in
 * the attic, so making them find and press the new button afterwards is a step
 * that earns nothing.
 */
async function addOfferedRoom(name) {
  try {
    const room = await api('/api/rooms', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name, is_custom: false }),
    });
    registry.rooms.push(room);
    registry.more_rooms = (registry.more_rooms ?? []).filter((n) => n.toLowerCase() !== room.name.toLowerCase());
    renderRoomChips();
    const made = $$('#roomChips .chip').find((c) => c.dataset.room === room.name);
    if (made) made.setAttribute('aria-pressed', 'true');
    $('#capRoomOther').hidden = true;
    cap.room = room.name;
    toast(`“${room.name}” added to your rooms.`);
  } catch {
    // Offline. The name still rides along with the item and the server creates
    // the room when it arrives, so nothing is lost by carrying on.
    cap.room = name;
  }
}

/*
 * A room typed by hand becomes a permanent choice.
 *
 * Registering it the moment they finish typing — rather than waiting for the
 * item to save — means it is already a chip if they add a second thing from the
 * same room, which is the common case when someone is standing in that room.
 */
async function rememberTypedRoom(name) {
  const clean = (name ?? '').trim();
  if (!clean || clean.toLowerCase() === 'other') return;
  if (registry.rooms.some((r) => r.name.toLowerCase() === clean.toLowerCase())) return;
  try {
    const room = await api('/api/rooms', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: clean }),
    });
    registry.rooms.push(room);
    renderRoomChips();
    // Keep the chip they just created selected, so nothing appears to reset.
    const made = $$('#roomChips .chip').find((c) => c.dataset.room === room.name);
    if (made) { made.setAttribute('aria-pressed', 'true'); $('#capRoomOther').hidden = true; }
    cap.room = room.name;
    toast(`“${room.name}” added to your rooms.`);
  } catch {
    // Offline, most likely. The name still rides along with the item and the
    // server will create the room when the item reaches it.
    cap.room = clean;
  }
}

// ------------------------------------------------------------------- boot
(async function boot() {
  registry = await api('/api/registry');
  renderRoomChips();
  renderCatChips();
  $('#filterRoom').innerHTML = '<option value="">All rooms</option>' +
    registry.rooms.map((r) => `<option value="${r.room_id}">${escapeHtml(r.name)}</option>`).join('');

  // The print and download links live in the markup as plain paths so they
  // stay readable; point them at the server wherever it happens to be.
  $$('[data-api-href]').forEach((a) => { a.href = API + a.dataset.apiHref; });

  mountPeopleScreen();
  $('#capRecipient').addEventListener('input', checkNewPerson);
  await loadPeople();

  resetCapture();

  /*
   * Where to land.
   *
   * Someone opening this for the first time has no idea why they should
   * bother, and a grid of buttons does not tell them. So a first-time visitor
   * gets the reason before the menu. Once there is anything in the list they
   * have clearly understood, and being lectured on every launch would be
   * patronising — they go straight to the menu, with the explanation still
   * one tap away.
   *
   * This is decided from the item count on the server rather than from
   * browser storage, so it survives a new phone, a cleared browser, or the
   * app being opened by a helping relative on their own device.
   */
  const { items } = await api('/api/items');
  $('#countPill').textContent = `${items.length} item${items.length === 1 ? '' : 's'}`;
  // An invited participant (partner or helper) arriving for the first time
  // gets their own welcome screen instead of the owner's onboarding.
  let landing = items.length === 0 ? 'welcome' : 'home';
  try {
    const summary = await api('/api/scope-summary');
    const role = summary?.participant?.role;
    if (role && role !== 'owner' && role !== 'bootstrap-owner' && items.length === 0) {
      landing = 'recipientwelcome';
    }
  } catch (e) { /* scope-summary not available — default to owner welcome */ }
  go(landing);
})();

/* =====================================================================
 * WALKING THE HOUSE, ROOM BY ROOM
 *
 * The app's centre of gravity. Everything here follows three findings from
 * watching the old flow fail:
 *
 * 1. The unit of work is the room, not the object. "Do the dining room" is a
 *    task someone can start and finish; "catalogue your possessions" is not.
 *
 * 2. Recording and naming must come apart. A recording is documentation the
 *    instant it is taken. Naming what is in it needs a model, a network and a
 *    decision from the owner, and demanding all three before anything is saved
 *    is why a walkthrough could appear to add nothing at all.
 *
 * 3. Stopping must be free. This gets done over days, in a house, by someone who
 *    will be interrupted. Pausing is a first-class action, and coming back must
 *    never require remembering where you were.
 * ===================================================================== */

let walk = null;        // last known state of the whole walk
let room = null;        // { room_id, name } currently open
let roomPending = [];   // captures taken in this room this sitting

/* ------------------------------------------------------------ offline store
 *
 * The implementation lives in offline-queue.js so the preview build can swap it
 * for a stub — see the comment at the top of that file. Everything below is a
 * thin delegation, and every caller must cope with the queue being unavailable.
 */
function offlineQueue() {
  return (
    window.LegacyOfflineQueue ?? {
      available: async () => false,
      add: async () => {
        throw new Error('no-idb');
      },
      all: async () => [],
      remove: async () => {},
    }
  );
}

const queueAdd = (record) => offlineQueue().add(record);
const queueAll = () => offlineQueue().all();
const queueRemove = (id) => offlineQueue().remove(id);
const queueAvailable = () => offlineQueue().available();

/** Is the server actually reachable, rather than merely "navigator says online"? */
async function serverReachable() {
  if (navigator.onLine === false) return false;
  try {
    const res = await fetch(`${API}/api/registry`, { method: 'GET', cache: 'no-store' });
    return res.ok;
  } catch { return false; }
}

/* ---------------------------------------------------------------- the walk */

async function loadWalk() {
  try {
    walk = await api('/api/walkthrough');
  } catch {
    // Offline: still show the rooms, from whatever the last load knew.
    walk = walk ?? { rooms: registry.rooms.map((r) => ({ ...r, walkthrough_state: 'not_started', item_count: 0 })),
      counts: { total: registry.rooms.length, done: 0, skipped: 0, in_progress: 0, not_started: registry.rooms.length, settled: 0 },
      next_room: registry.rooms[0] ? { room_id: registry.rooms[0].room_id, name: registry.rooms[0].name } : null,
      is_complete: false, unfinished: [] };
  }
  renderWalk();
}

const ROOM_STATUS = {
  done: { word: 'Finished', cls: 'st-done', mark: '✓' },
  skipped: { word: 'Nothing to record', cls: 'st-skip', mark: '—' },
  started: { word: 'Part way through', cls: 'st-part', mark: '…' },
  not_started: { word: 'Not started', cls: 'st-none', mark: '' },
};

function renderWalk() {
  const c = walk.counts;
  $('#walkProgress').hidden = c.total === 0;
  const pct = c.total ? Math.round((c.settled / c.total) * 100) : 0;
  $('#walkBarFill').style.width = `${pct}%`;
  $('#walkCount').textContent = c.settled === 0
    ? `${c.total} rooms on your list.`
    : `${c.settled} of ${c.total} rooms finished.`;

  $('#walkRooms').innerHTML = walk.rooms.map((r) => {
    const st = ROOM_STATUS[r.walkthrough_state] ?? ROOM_STATUS.not_started;
    const bits = [];
    if (r.item_count) bits.push(`${r.item_count} thing${r.item_count === 1 ? '' : 's'} named`);
    if (r.documented_at && !r.item_count) bits.push('recorded');
    return `<button class="roomrow ${st.cls}" data-room-id="${r.room_id}" data-room-name="${escapeHtml(r.name)}">
        <span class="roomrow-mark" aria-hidden="true">${st.mark}</span>
        <span class="roomrow-body">
          <span class="roomrow-name">${escapeHtml(r.name)}</span>
          <span class="roomrow-state">${st.word}${bits.length ? ` · ${bits.join(' · ')}` : ''}</span>
        </span>
      </button>`;
  }).join('');
  $$('#walkRooms .roomrow').forEach((b) => {
    b.onclick = () => openRoom(b.dataset.roomId, b.dataset.roomName);
  });

  const next = walk.next_room;
  $('#walkNext').hidden = !next || walk.is_complete;
  if (next) {
    $('#walkNextBtn').textContent = `Start the ${next.name}`;
    $('#walkNextBtn').onclick = () => openRoom(next.room_id, next.name);
  }
  $('#walkDone').hidden = !walk.is_complete;
}

/* --------------------------------------------------------- inside one room */

async function openRoom(roomId, name) {
  room = { room_id: roomId, name };
  roomPending = [];
  go('room');
  $('#roomTitle').textContent = name;
  renderRoomState();
  // Opening a room is itself progress worth remembering, so a pause right after
  // this still brings them back to the right place.
  try {
    const res = await api(`/api/rooms/${roomId}/state`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ state: 'started' }),
    });
    walk = res.walkthrough;
  } catch { /* offline: the room is open locally regardless */ }
}

function renderRoomState() {
  const known = walk?.rooms?.find((r) => r.room_id === room.room_id);
  const named = known?.item_count ?? 0;
  const recorded = !!known?.documented_at || roomPending.length > 0;
  const parts = [];
  if (recorded) parts.push('This room has been recorded.');
  if (named) parts.push(`${named} thing${named === 1 ? '' : 's'} named here.`);
  $('#roomStats').innerHTML = parts.length
    ? `<p class="roomstat-ok">${parts.join(' ')}</p>`
    : '<p class="roomstat-todo">Nothing recorded in here yet.</p>';

  $('#roomCaptured').hidden = roomPending.length === 0;
  $('#roomCaptured').innerHTML = roomPending.map((p) => `
    <div class="capt">
      <p class="capt-line">${p.saved ? '✓ Saved' : '⏳ Held on this device'} — ${escapeHtml(p.label)}</p>
      ${p.frames?.length ? `<button class="ghost wide" data-name-these="${p.key}">Write down what is in it${p.frames.length ? ` (${p.frames.length} pictures)` : ''}</button>` : ''}
      ${p.saved ? '' : '<p class="capt-note">It will be sent when you next have internet.</p>'}
    </div>`).join('');
  $$('#roomCaptured [data-name-these]').forEach((b) => {
    b.onclick = () => offerNaming(b.dataset.nameThese);
  });
}

/* --------------------------------------------- record first, name afterwards */

/**
 * Take the recording in. Documenting comes first and never depends on the model
 * or the network; naming is offered afterwards and may be declined or deferred
 * indefinitely without anything being lost.
 */
async function captureRoomMedia(file, kind) {
  const key = `c${Date.now()}`;
  const label = kind === 'video' ? 'Video walkthrough' : `${file.length ?? 1} photo(s)`;
  const entry = { key, label, saved: false, frames: [], kind };
  roomPending.push(entry);
  renderRoomState();
  toast('Keeping the recording…');

  // Pull stills out of a video so a later naming pass has something to look at
  // without needing the whole file again. Failure here is not fatal: the
  // recording itself is the record, and the frames are only a convenience.
  if (kind === 'video') {
    try {
      const { frames } = await framesFromVideo(file, MAX_FRAMES);
      entry.frames = frames;
    } catch { entry.frames = []; }
  }

  const online = await serverReachable();
  if (online) {
    try {
      await fetch(`${API}/api/scope-media?title=${encodeURIComponent(`${room.name} — walkthrough`)}`
        + `&room=${encodeURIComponent(room.name)}`, {
        method: 'POST', headers: { 'content-type': file.type || 'video/mp4' }, body: file,
      });
      entry.saved = true;
      await api(`/api/rooms/${room.room_id}/state`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ state: 'started', documented: true }),
      }).then((r) => { walk = r.walkthrough; }).catch(() => {});
      toast('Recorded and saved.');
    } catch {
      entry.saved = false;
    }
  }

  if (!entry.saved) {
    try {
      await queueAdd({ room_id: room.room_id, room_name: room.name, kind, blob: file, type: file.type || '' });
      toast('Saved on this phone. It will be sent when you have internet.');
    } catch {
      toast('This device could not hold the recording. Please try again with internet.', true);
      roomPending = roomPending.filter((p) => p.key !== key);
    }
  }
  renderRoomState();
  await refreshQueueBadge();
}

/**
 * The optional naming pass.
 *
 * Never automatic. The owner asked for the room to be documented and that is
 * done; putting names to things is a separate offer, and it says plainly when
 * the guesses are not coming from a real model so nothing invented is mistaken
 * for a finding.
 */
async function offerNaming(key) {
  const entry = roomPending.find((p) => p.key === key);
  if (!entry?.frames?.length) return;
  if (!(await serverReachable())) {
    toast('Naming needs internet. The recording is safe until then.', true);
    return;
  }
  toast('Looking through the recording…');
  inRoomNaming = true;
  roomDupCount = 0;
  try {
    const { detections, vision_mode } = await api('/api/intake/detect', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        images: entry.frames.map((dataUrl, i) => ({ data_url: dataUrl, frame_index: i, media_id: `${key}-${i}` })),
        room_hint: room.name,
      }),
    });
    batchFiles = entry.frames.map((dataUrl, i) => ({ _dataUrl: dataUrl, _frame: i }));
    showNamingResults(detections, vision_mode);
  } catch (e) {
    toast(e.message, true);
  }
}

/**
 * What happens after a room has been read.
 *
 * The owner is not asked to approve the camera's work item by item. The purpose
 * of this registry is to document that things EXIST, so a lower standard of
 * precision is the right one here: everything found goes straight onto the list,
 * confirmed, and a wrong entry costs nothing because the scrutiny happens later
 * in Reindeer: FairPlay, where it matters and where the tools for it live.
 *
 * Then exactly one question is asked, about the room and never about an item.
 * "No" is a complete answer that is never asked again. The app does not point at
 * a possession and ask who should have it — naming an heir is always the owner
 * reaching for it, never the app requesting it.
 */
async function showNamingResults(detections, mode) {
  go('batch');
  const intake = $('#batchIntake');
  if (intake) intake.hidden = true;
  const warn = mode === 'mock'
    ? `<div class="mockwarn"><p><strong>These are examples, not real findings.</strong>
         The picture-reading service is not switched on yet, so the names below were
         made up by the app rather than read from your recording.</p></div>`
    : '';
  const n = detections.length;
  if (!n) {
    $('#batchResults').innerHTML = `${warn}
      <h2>Nothing was recognised in that recording</h2>
      <p class="reassure">The recording itself is saved with your inventory either way.
        A shorter walk through one room, pausing on each thing, usually reads better.</p>
      <button class="ghost wide" id="namingBack">Back to the room</button>`;
    $('#namingBack').onclick = () => leaveNaming();
    return;
  }

  $('#batchResults').innerHTML = `${warn}
    <h2>Writing down ${n} thing${n === 1 ? '' : 's'}…</h2>
    <p class="reassure">There is nothing for you to check. They are going on your list as they are.</p>`;

  let added = [];
  try {
    added = await commitEverything(detections);
  } catch (e) {
    $('#batchResults').innerHTML = `${warn}
      <h2>Those could not be saved</h2>
      <p class="reassure">${escapeHtml(e.message)} The recording is still safe.</p>
      <button class="ghost wide" id="namingBack">Back to the room</button>`;
    $('#namingBack').onclick = () => leaveNaming();
    return;
  }
  renderRoomGiftAsk(added);
}

/**
 * Save every detection, confirmed, in one request.
 *
 * The room is passed as room_hint because that is the field the commit route
 * reads; sending 'room' left a whole walkthrough's items filed under no room at
 * all. Items land confirmed rather than as drafts, so nothing on the list ever
 * wears a mark implying the owner still owes it a decision.
 */
async function commitEverything(detections) {
  const payload = [];
  for (const d of detections) {
    const src = batchFiles[d.frame_index ?? 0];
    const crop = src ? await cropTo(src._dataUrl, d.bbox) : null;
    payload.push({ ...d, crop_data_url: crop, room_hint: room?.name ?? d.room_hint ?? d.room ?? null });
  }
  const { created, possible_duplicates } = await api('/api/intake/commit', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ detections: payload }),
  });
  // Mentioned once on the way out, as information. Never a task.
  if (possible_duplicates > 0) roomDupCount += possible_duplicates;
  await Promise.all(created.map((id) => api(`/api/items/${id}/keep`, { method: 'POST' }).catch(() => {})));
  refreshCount();
  return created.map((id, i) => ({
    item_id: id,
    label: detections[i]?.label ?? 'Item',
    thumb: payload[i]?.crop_data_url || batchFiles[detections[i]?.frame_index ?? 0]?._dataUrl || '',
  }));
}

/** The one question. Asked about the room, once, and never repeated. */
function renderRoomGiftAsk(added, again = false) {
  const n = added.length;
  $('#batchResults').innerHTML = `
    ${again ? '' : `<h2>${n} thing${n === 1 ? '' : 's'} in the ${escapeHtml(room?.name ?? 'room')}
      ${n === 1 ? 'is' : 'are'} on your list</h2>
    <p class="reassure">That part is done. They are written down and they will print.</p>`}
    <div class="ask">
      <p class="askq">${again
        ? 'Anything else in here meant for someone in particular?'
        : 'Did you see anything in here that is meant for someone in particular?'}</p>
      <button class="primary wide" id="giftYes">Yes — let me point ${again ? 'more' : 'them'} out</button>
      <button class="ghost wide" id="giftNo">${again ? 'No — that is everything' : 'No — on to the next room'}</button>
    </div>`;
  $('#giftNo').onclick = () => leaveNaming();
  $('#giftYes').onclick = () => renderGiftPicker(added);
}

/**
 * Point at several things, then say one name.
 *
 * More than one item at a time on purpose: a set of dining chairs, a pair of
 * lamps, or three pieces of one grandmother's china are one decision to the
 * owner and should not cost three passes through a form.
 */
function renderGiftPicker(added) {
  const picked = new Set();
  $('#batchResults').innerHTML = `
    <h2>Which ones?</h2>
    <p class="reassure">Tap as many as you like. They can all go to the same person.</p>
    <div class="picks">
      ${added.map((a) => `
        <button class="pick" data-pick-id="${a.item_id}" aria-pressed="false">
          ${a.thumb ? `<img src="${a.thumb}" alt="">` : '<span class="noimg">no picture</span>'}
          <span class="picklbl">${escapeHtml(a.label)}</span>
        </button>`).join('')}
    </div>
    <div id="giftWhoBox" hidden>
      <h3>Who are they for?</h3>
      <div class="chips" id="giftChips"></div>
      <input type="text" id="giftName" class="bigin" placeholder="A name">
      <input type="text" id="giftRel" class="bigin" placeholder="Relationship, for example: daughter">
      <button class="primary wide" id="giftSave">Save this</button>
      <p class="reassure">This is a wish, not a legal instruction. You can change it any time.</p>
    </div>
    <button class="ghost wide" id="giftCancel">Never mind</button>`;

  const box = $('#giftWhoBox');
  $$('.picks .pick').forEach((b) => {
    b.onclick = () => {
      const id = b.dataset.pickId;
      const on = b.getAttribute('aria-pressed') === 'true';
      b.setAttribute('aria-pressed', on ? 'false' : 'true');
      if (on) picked.delete(id); else picked.add(id);
      box.hidden = picked.size === 0;
      $('#giftSave').textContent = picked.size > 1 ? `Save these ${picked.size}` : 'Save this';
    };
  });

  // The roster, so the second and third gift are one tap each.
  const chips = $('#giftChips');
  chips.innerHTML = people.filter((p) => !p.archived).map((p) =>
    `<button class="chip" data-gift-pick="${escapeHtml(p.name)}" data-rel="${escapeHtml(p.relationship ?? '')}" aria-pressed="false">${escapeHtml(p.name)}${p.relationship ? ` <span class="chiprel">${escapeHtml(p.relationship)}</span>` : ''}</button>`).join('');
  $$('#giftChips .chip').forEach((c) => {
    c.onclick = () => {
      $$('#giftChips .chip').forEach((o) => o.setAttribute('aria-pressed', 'false'));
      c.setAttribute('aria-pressed', 'true');
      $('#giftName').value = c.dataset.giftPick;
      $('#giftRel').value = c.dataset.rel || '';
    };
  });

  $('#giftCancel').onclick = () => renderRoomGiftAsk(added, true);
  $('#giftSave').onclick = async () => {
    const name = $('#giftName').value.trim();
    if (!name) return toast('Please put in a name, or press Never mind.', true);
    const rel = $('#giftRel').value.trim();
    $('#giftSave').disabled = true;
    const ids = [...picked];
    try {
      for (const id of ids) {
        await api(`/api/items/${id}`, {
          method: 'PATCH', headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ recipient_hint: { recipient_name: name, relationship: rel, owner_note: '' } }),
        });
      }
      try { await addPerson(name, rel, 'from_item'); } catch { /* not worth stopping for */ }
      toast(`${ids.length === 1 ? 'That one is' : `Those ${ids.length} are`} for ${name}.`);
      const left = added.filter((a) => !picked.has(a.item_id));
      if (!left.length) return leaveNaming();
      renderRoomGiftAsk(left, true);
    } catch (e) {
      $('#giftSave').disabled = false;
      toast(e.message, true);
    }
  };
}

/**
 * Coming back out of the naming pass. This is where the duplicate tally is
 * finally spoken, once, and only as information — never as a task.
 */
async function leaveNaming() {
  inRoomNaming = false;
  go('room');
  // Re-read the walk so the room's own tally reflects what was just kept,
  // rather than the count from before the naming pass.
  try { walk = await api('/api/walkthrough'); } catch { /* keep what we have */ }
  renderRoomState();
  if (roomDupCount > 0) {
    const n = roomDupCount;
    roomDupCount = 0;
    toast(`Saved. ${n === 1 ? 'One thing' : `${n} things`} may already be on your list — `
      + 'you can check that any time under My items, or leave it.');
  }
}

/* ------------------------------------------------------- finishing a room */

async function setRoomFinished(state) {
  inRoomNaming = false;
  const word = state === 'skipped' ? 'Nothing to record here' : 'Finished';
  try {
    const res = await api(`/api/rooms/${room.room_id}/state`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ state }),
    });
    walk = res.walkthrough;
    toast(`${room.name}: ${word.toLowerCase()}.`);
  } catch {
    toast('Saved on this device. It will catch up when you have internet.');
  }
  // Straight to the next room, because that is almost always what they want.
  go('walk');
  renderWalk();
  if (walk.is_complete) return;
  const next = walk.next_room;
  if (next) toast(`Next: the ${next.name}. Or stop here — it will keep.`);
}

/* ---------------------------------------------------------------- pausing */

/**
 * Stopping is a real choice, so it gets a real answer: what is done, what is
 * left, and an explicit promise that nothing needs finishing today.
 */
function pauseWalk() {
  const left = walk?.unfinished?.length ?? 0;
  go('home');
  renderResume();
  toast(left
    ? `Stopped. ${left} room${left === 1 ? '' : 's'} still to do, waiting for you.`
    : 'Stopped. Everything is saved.');
}

async function renderResume() {
  // On a cold start nothing has been loaded yet, and this panel is the first
  // thing a returning owner should see — so fetch it here rather than making
  // them find the room list to be reminded where they were.
  if (!walk) {
    try { walk = await api('/api/walkthrough'); } catch { $('#resumePanel').hidden = true; return; }
  }
  const c = walk?.counts;
  if (!c || c.total === 0 || c.settled === 0 || walk.is_complete) {
    $('#resumePanel').hidden = true;
    return;
  }
  $('#resumePanel').hidden = false;
  const next = walk.next_room;

  // Say honestly whether the next room was already begun or has not been opened
  // yet. "You were up to the Living Room" told a room that was never started the
  // same story as one left half-done, and an owner who cannot remember which is
  // which is precisely the person this app is for.
  const nextRow = next ? walk.unfinished.find((r) => r.room_id === next.room_id) : null;
  const alreadyBegun = nextRow?.state === 'started';
  $('#resumeLine').textContent =
    `You have finished ${c.settled} of ${c.total} rooms.` +
    (next
      ? alreadyBegun
        ? ` You were part-way through the ${next.name}.`
        : ` The ${next.name} is next.`
      : '');
  $('#resumeBtn').textContent = next ? `Carry on with the ${next.name}` : 'Carry on';
  $('#resumeBtn').onclick = () => (next ? openRoom(next.room_id, next.name) : go('walk'));

  // The room they are about to walk into does not belong in the list of rooms
  // still waiting. Naming it in both places read as a contradiction: told they
  // were in the Living Room, then told the Living Room was still to do.
  const later = walk.unfinished.filter((r) => r.room_id !== next?.room_id);
  const rest = later.slice(0, 6).map((r) => r.name);
  $('#resumeRest').textContent = later.length
    ? `After that: ${rest.join(', ')}${later.length > rest.length ? `, and ${later.length - rest.length} more` : ''}.`
    : next
      ? 'That is the last room.'
      : '';
}

/* ------------------------------------------------------- the upload queue */

async function refreshQueueBadge() {
  const pending = await queueAll();
  const el = $('#queueBadge');
  if (!el) return;

  // If this device cannot hold anything back, say so before a room is recorded
  // rather than after. Finding out at the end of a walk through the house, with
  // the recording already made and about to be lost, would be the cruellest
  // possible moment to mention it.
  if (!pending.length && !(await queueAvailable())) {
    el.hidden = false;
    // Quiet, not alarming. Nothing is wrong and nothing is lost: the app works
    // normally, it just needs a connection. A full-width red panel above the
    // menu made a footnote look like a fault, so this states it in one line and
    // gets out of the way.
    el.className = 'queuebadge quiet';
    el.innerHTML = '<p class="qb-quiet">This device needs internet while you work — '
      + 'it cannot hold recordings to send later. A phone or tablet can.</p>';
    return;
  }

  // Recordings actually waiting on the device are a different matter: that is
  // unsent work, and it stays prominent until it is sent.
  el.className = 'queuebadge';
  el.hidden = pending.length === 0;
  if (pending.length) {
    el.innerHTML = `<p class="qb-line"><strong>${pending.length} recording${pending.length === 1 ? '' : 's'}</strong>
        waiting on this device.</p>
      <p class="qb-note">They are safe here. Send them when you next have internet &mdash;
        at a family member's house, or at your trust or solicitor's office.</p>
      <button class="primary wide" id="queueSendBtn">Send them now</button>`;
    $('#queueSendBtn').onclick = uploadQueue;
  }
}

async function uploadQueue() {
  const pending = await queueAll();
  if (!pending.length) return;
  if (!(await serverReachable())) {
    toast('Still no internet. Nothing was lost — try again later.', true);
    return;
  }
  const btn = $('#queueSendBtn');
  if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }
  let sent = 0;
  for (const rec of pending) {
    try {
      await fetch(`${API}/api/scope-media?title=${encodeURIComponent(`${rec.room_name} — walkthrough`)}`
        + `&room=${encodeURIComponent(rec.room_name)}`, {
        method: 'POST', headers: { 'content-type': rec.type || 'video/mp4' }, body: rec.blob,
      });
      await api(`/api/rooms/${rec.room_id}/state`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ state: 'started', documented: true }),
      }).catch(() => {});
      await queueRemove(rec.id);
      sent += 1;
    } catch { /* leave it queued and try again next time */ }
  }
  toast(sent === pending.length
    ? `All ${sent} recording${sent === 1 ? '' : 's'} sent.`
    : `${sent} of ${pending.length} sent. The rest are still safe here.`);
  await refreshQueueBadge();
  await loadWalk();
  if (btn) { btn.disabled = false; btn.textContent = 'Send them now'; }
}

/* ------------------------------------------------- wiring the walk screens */
$('#walkNewRoom')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#walkAddRoom').click(); });

$('#walkAddRoom').onclick = async () => {
  const name = $('#walkNewRoom').value.trim();
  if (!name) { toast('Type a name for the room first.', true); return; }
  if (registry.rooms.some((r) => r.name.toLowerCase() === name.toLowerCase())) {
    toast('That room is already on your list.', true);
    $('#walkNewRoom').value = '';
    return;
  }
  try {
    const created = await api('/api/rooms', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name }),
    });
    registry.rooms.push(created);
    renderRoomChips();
    $('#walkNewRoom').value = '';
    await loadWalk();
    toast(`“${created.name}” added. It stays on your list.`);
  } catch (e) {
    toast('Could not add that room right now. Please try again when you have internet.', true);
  }
};

$('#roomVideo').onchange = async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (file) await captureRoomMedia(file, 'video');
};

$('#roomPhotos').onchange = async (e) => {
  const files = [...e.target.files];
  e.target.value = '';
  if (!files.length) return;
  // Photos are already stills, so they go straight to naming as frames while the
  // originals are kept exactly as the video path keeps its recording.
  const key = `p${Date.now()}`;
  const entry = { key, label: `${files.length} photo${files.length === 1 ? '' : 's'}`, saved: false, frames: [], kind: 'photos' };
  roomPending.push(entry);
  renderRoomState();
  for (const f of files.slice(0, MAX_FRAMES)) {
    entry.frames.push(await new Promise((res) => {
      const fr = new FileReader();
      fr.onload = () => res(fr.result);
      fr.readAsDataURL(f);
    }));
  }
  const online = await serverReachable();
  if (online) {
    try {
      await api(`/api/rooms/${room.room_id}/state`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ state: 'started', documented: true }),
      }).then((r) => { walk = r.walkthrough; });
      entry.saved = true;
    } catch { entry.saved = false; }
  }
  if (!entry.saved) {
    try { await queueAdd({ room_id: room.room_id, room_name: room.name, kind: 'photos', blob: files[0], type: files[0].type || '' }); }
    catch { /* the frames are still in memory for naming right now */ }
  }
  renderRoomState();
  await refreshQueueBadge();
  toast('Photos kept. You can name what is in them now, or later.');
};

// "Add one thing carefully" hands over to the guided capture, pre-filled with
// the room so the owner is not asked where they are standing.
$('#roomOneItem').onclick = () => {
  resetCapture();
  go('capture');
  if (room?.name) {
    cap.room = room.name;
    const chip = $$('#roomChips .chip').find((c) => c.dataset.room === room.name);
    if (chip) chip.setAttribute('aria-pressed', 'true');
  }
};

$('#roomDoneBtn').onclick = () => setRoomFinished('done');
$('#roomSkipBtn').onclick = () => setRoomFinished('skipped');
$('#roomPauseBtn').onclick = () => pauseWalk();

// If the phone regains a connection mid-walk, say so once rather than silently
// changing behaviour, and never upload without being asked.
window.addEventListener('online', async () => {
  const pending = await queueAll();
  if (pending.length) {
    await refreshQueueBadge();
    toast(`Internet is back. ${pending.length} recording${pending.length === 1 ? '' : 's'} ready to send.`);
  }
});

/* =========================================================================
 * SPECIAL GIFTS BY NAME (the addendum family)
 *
 * State
 *   giftsState.heirs           full list from /api/two-outputs/heirs
 *   giftsState.preview         GET /api/two-outputs/addendum/preview
 *   giftsState.editing         null | heir_id being edited on giftperson screen
 *   giftsState.newKind         'heir' | 'named_recipient' when adding
 *   giftsState.trustees        for the trustee <select> on sign screen
 *
 * "Heirs" and "named_recipients" live in the same DB table because the app
 * has to reason about both as `recipient_type`. The UI shows them as two
 * lists to keep the mental model clean: heirs are the will's people;
 * named-recipients are everybody else the owner wants to name.
 * ========================================================================= */

// The Registry is a single-owner app. `resolveScope()` on the server sets
// actorId to 'owner', so the twoOutputsRouter accepts 'owner' as a stable
// owner_participant_id for a Registry install. FairPlay, by contrast,
// derives this from the signed-in administrator's participant record.
const REGISTRY_OWNER_PARTICIPANT_ID = 'owner';

const giftsState = {
  heirs: [],
  preview: null,
  editing: null,
  newKind: 'heir',
  trustees: [],
  allItems: [],
};

async function loadGifts() {
  try {
    const [heirsRes, previewRes, itemsRes] = await Promise.all([
      api('/api/two-outputs/heirs'),
      api(`/api/two-outputs/addendum/preview?owner_participant_id=${encodeURIComponent(REGISTRY_OWNER_PARTICIPANT_ID)}`).catch(() => null),
      // Item list is used to find important-but-unassigned items \u2014 the
      // "Still to decide" nudge on the roster and the sign screen.
      api('/api/items').catch(() => ({ items: [] })),
    ]);
    giftsState.heirs = heirsRes.heirs ?? [];
    giftsState.preview = previewRes ?? { items: [], gaps: [], counts: { assigned_items: 0 } };
    giftsState.allItems = itemsRes.items ?? [];
    renderGiftsRoster();
    renderGiftsStillToDecide();
    updateGiftsTileHint();
  } catch (e) {
    toast(`Could not load your list: ${e.message}`, true);
  }
}

function updateGiftsTileHint() {
  const hint = $('#giftsTileHint');
  if (!hint) return;
  const n = giftsState.heirs.length;
  const assigned = giftsState.preview?.counts?.assigned_items ?? 0;
  if (n === 0) hint.textContent = 'Say who a particular thing is for. Friends and charities count too, not only heirs';
  else if (assigned === 0) hint.textContent = `${n} ${n === 1 ? 'person' : 'people'} on the list, nothing given to them yet`;
  else hint.textContent = `${assigned} thing${assigned === 1 ? '' : 's'} promised to ${n} ${n === 1 ? 'person' : 'people'}`;
}

// Group items by the person they are assigned to. The preview endpoint
// already tells us who each item is going to; we group client-side so a
// stale bit of preview doesn't lose a freshly-edited assignment.
function itemsByHeir() {
  const buckets = new Map();
  for (const it of giftsState.preview?.items ?? []) {
    const id = it.assigned_to?.heir_id;
    if (!id) continue;
    if (!buckets.has(id)) buckets.set(id, []);
    buckets.get(id).push(it);
  }
  return buckets;
}

function renderGiftsRoster() {
  const byHeir = itemsByHeir();

  const heirs = giftsState.heirs.filter((h) => (h.recipient_type || 'heir') === 'heir');
  const named = giftsState.heirs.filter((h) => h.recipient_type === 'named_recipient');

  const paint = (list, boxSel, emptyMsg) => {
    const box = $(boxSel);
    if (!list.length) {
      box.innerHTML = `<p class="reassure" style="margin:0">${emptyMsg}</p>`;
      return;
    }
    box.innerHTML = list.map((h) => {
      const items = byHeir.get(h.heir_id) ?? [];
      const rel = h.relationship ? ` <span class="personrel">${escapeHtml(h.relationship)}</span>` : '';
      const count = items.length
        ? `${items.length} thing${items.length === 1 ? '' : 's'}`
        : 'nothing yet';
      return `
        <button class="personrow giftrow" data-heir="${escapeHtml(h.heir_id)}">
          <span class="personwho">
            <span class="personname">${escapeHtml(h.name)}</span>${rel}
          </span>
          <span class="personcount">${count}</span>
        </button>`;
    }).join('');
    $$(`${boxSel} [data-heir]`).forEach((b) => {
      b.onclick = () => openGiftPerson(b.dataset.heir);
    });
  };

  paint(heirs, '#giftsHeirs',
    'Nobody added yet. Add the first heir with "Add somebody" above.');
  paint(named, '#giftsNamed',
    'Nobody added yet. Use "Add somebody" if you want to leave a specific item to a friend, a godchild, or a charity.');
}

// Items the owner has flagged Important but not yet assigned to anyone.
// A soft nudge, never a wall.
function renderGiftsStillToDecide() {
  const box = $('#giftsStillToDecide');
  if (!box) return;
  // We compute this from the item list itself, not preview.gaps. Gaps are
  // items that ARE assigned but had a missing closeup or dead heir_id;
  // "still to decide" is a different concept: important but unassigned.
  const importantUnassigned = (giftsState.allItems ?? [])
    .filter((it) => (it.important === 1 || it.important === true)
      && !it.assigned_to_heir_id
      && it.deleted_at == null);
  if (!importantUnassigned.length) { box.hidden = true; box.innerHTML = ''; return; }
  box.hidden = false;
  const rows = importantUnassigned.slice(0, 8).map((it) => `
    <li><button class="linky" data-decide="${escapeHtml(it.item_id)}">${escapeHtml(it.title || 'Untitled item')}</button></li>
  `).join('');
  const extra = importantUnassigned.length > 8 ? `<p class="reassure">\u2026 and ${importantUnassigned.length - 8} more.</p>` : '';
  box.innerHTML = `
    <h3>Still to decide</h3>
    <p class="reassure">You marked these Important but haven't said who they are for. That is fine \u2014 you can leave them for the game
    to decide, or come back and name someone later.</p>
    <ul class="still-list">${rows}</ul>
    ${extra}`;
  $$('#giftsStillToDecide [data-decide]').forEach((b) => {
    b.onclick = () => go('detail', { item_id: b.dataset.decide });
  });
}

/* ---- One-person editor ---- */

function resetGiftPerson() {
  giftsState.editing = null;
  giftsState.newKind = 'heir';
  $('#giftPersonHeading').textContent = 'Add somebody';
  $('#giftPersonName').value = '';
  $('#giftPersonRel').value = '';
  $('#giftPersonEmail').value = '';
  $('#giftPersonNotes').value = '';
  setGiftKind('heir');
  $('#giftPersonRemove').hidden = true;
  $('#giftPersonItems').hidden = true;
}

function openGiftPerson(heirId) {
  const h = giftsState.heirs.find((x) => x.heir_id === heirId);
  if (!h) return;
  giftsState.editing = heirId;
  $('#giftPersonHeading').textContent = h.name;
  $('#giftPersonName').value = h.name;
  $('#giftPersonRel').value = h.relationship || '';
  $('#giftPersonEmail').value = h.email || '';
  $('#giftPersonNotes').value = h.notes || '';
  setGiftKind(h.recipient_type || 'heir');
  $('#giftPersonRemove').hidden = false;
  renderGiftPersonItems(heirId);
  go('giftperson', { editing: true });
}

function setGiftKind(kind) {
  giftsState.newKind = kind;
  $$('#giftKindChips .chip').forEach((c) => {
    c.setAttribute('aria-pressed', c.dataset.kind === kind ? 'true' : 'false');
  });
}

function renderGiftPersonItems(heirId) {
  const items = (giftsState.preview?.items ?? []).filter((i) => i.assigned_to?.heir_id === heirId);
  const box = $('#giftPersonItems');
  const list = $('#giftPersonItemList');
  box.hidden = false;
  if (!items.length) {
    list.innerHTML = '<p class="reassure" style="margin:0">Nothing named for this person yet. '
      + 'Tap "Add items for this person" to pick some from your list.</p>';
    return;
  }
  list.innerHTML = items.map((it) => `
    <div class="giftitem">
      <div class="giftitem-title">${escapeHtml(it.title || 'Untitled item')}</div>
      ${it.room_name ? `<div class="giftitem-room">${escapeHtml(it.room_name)}</div>` : ''}
      <button class="linky" data-unassign="${escapeHtml(it.item_id)}">Not for them any more</button>
    </div>`).join('');
  $$('#giftPersonItemList [data-unassign]').forEach((b) => {
    b.onclick = async () => {
      if (!confirm('Take this item off their list?\n\nThe item itself is not deleted, just unassigned.')) return;
      try {
        await api(`/api/items/${b.dataset.unassign}/assign`, {
          method: 'PATCH', headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ heir_id: null }),
        });
        await loadGifts();
        openGiftPerson(heirId);
        toast('Taken off their list.');
      } catch (e) { toast(e.message, true); }
    };
  });
}

$$('#giftKindChips .chip').forEach((c) => { c.onclick = () => setGiftKind(c.dataset.kind); });

$('#giftAddBtn').onclick = () => { resetGiftPerson(); go('giftperson'); };
$('#giftSignBtn').onclick = () => go('giftsign');
$('#giftVersionsBtn').onclick = () => go('giftversions');
$('#giftPersonCancel').onclick = () => go('gifts');

$('#giftPersonSave').onclick = async () => {
  const name = $('#giftPersonName').value.trim();
  if (!name) { toast('Please write their name first.', true); return; }
  const body = {
    name,
    relationship: $('#giftPersonRel').value.trim(),
    email: $('#giftPersonEmail').value.trim(),
    notes: $('#giftPersonNotes').value.trim(),
    recipient_type: giftsState.newKind,
  };
  try {
    if (giftsState.editing) {
      await api(`/api/two-outputs/heirs/${giftsState.editing}`, {
        method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body),
      });
      toast('Saved.');
    } else {
      await api('/api/two-outputs/heirs', {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body),
      });
      toast('Added to your list.');
    }
    await loadGifts();
    go('gifts');
  } catch (e) { toast(e.message, true); }
};

$('#giftPersonRemove').onclick = async () => {
  if (!giftsState.editing) return;
  const h = giftsState.heirs.find((x) => x.heir_id === giftsState.editing);
  if (!h) return;
  if (!confirm(`Take ${h.name} off your list?\n\nYou can only remove someone with no items assigned to them. If they have items, unassign those first.`)) return;
  try {
    await api(`/api/two-outputs/heirs/${giftsState.editing}`, { method: 'DELETE' });
    toast('Removed.');
    await loadGifts();
    go('gifts');
  } catch (e) { toast(e.message, true); }
};

/* ---- Confirm your choices (was: Sign the memorandum) ---- */

async function loadGiftSign() {
  $('#giftSignError').hidden = true;
  // The single confirmation input. There used to be a separate "your full
  // legal name" input here \u2014 it was removed when we collapsed the sign
  // screen to one box, because the app already knows the owner's name
  // from their account and the printed paper carries the handwritten
  // signature. See docs/handoffs/2026-08-09-sign-copy-v3.md.
  $('#giftSignerAck').value = '';
  await loadTrusteesForSign();
  try {
    const preview = await api(`/api/two-outputs/addendum/preview?owner_participant_id=${encodeURIComponent(REGISTRY_OWNER_PARTICIPANT_ID)}`);
    giftsState.preview = preview;
    renderGiftSignSummary(preview);
    renderGiftSignItems(preview);
    renderGiftsStillToDecide();
  } catch (e) {
    // The two most common blockers are "no items assigned yet" and
    // "no wills caretaker or trustee on file". Surface both plainly
    // instead of the raw error, and keep the trustee picker visible so
    // the owner has somewhere to go next.
    giftsState.preview = null;
    const msg = String(e.message || '');
    const noRecip = /caretaker or trustee/i.test(msg);
    const noItems = /no items assigned/i.test(msg);
    const detail = noRecip
      ? 'You need one wills caretaker or trustee on file before you can confirm your list. Add one in the Trustee section, then come back.'
      : noItems
        ? 'You have not added anything to your list of special gifting yet. Go back and assign at least one thing to a person on your list.'
        : msg;
    $('#giftSignSummary').innerHTML = `<div class="sign-box" style="border-color:#c68a2b;background:#fff7e6"><div class="sign-line">${escapeHtml(detail)}</div></div>`;
    $('#giftSignItems').innerHTML = '';
    renderGiftsStillToDecide();
  }
}

async function loadTrusteesForSign() {
  try {
    const res = await api('/api/two-outputs/wills-caretakers');
    giftsState.trustees = res.wills_caretakers ?? res.people ?? [];
    const sel = $('#giftSignerTrustee');
    sel.innerHTML = '<option value="">\u2014 choose or leave blank \u2014</option>'
      + giftsState.trustees.map((t) => `<option value="${escapeHtml(t.wills_caretaker_id ?? t.person_id ?? '')}">${escapeHtml(t.name)}${t.relationship ? ' \u2014 ' + escapeHtml(t.relationship) : ''}</option>`).join('');
  } catch { /* trustee list is optional context */ }
}

function renderGiftSignSummary(preview) {
  // The server returns { envelope, nextVersion, supersedesVersion, gaps }.
  // Items live under envelope.items.
  const items = preview?.envelope?.items ?? [];
  const heirIds = new Set(items.map((i) => i.assigned_to?.heir_id).filter(Boolean));
  $('#giftSignSummary').innerHTML = `
    <div class="sign-box">
      <div class="sign-line"><b>${items.length}</b> item${items.length === 1 ? '' : 's'} going to
        <b>${heirIds.size}</b> ${heirIds.size === 1 ? 'person' : 'people'}</div>
      <div class="sign-line reassure">If you confirm now, that is what your trustee will see.</div>
    </div>`;
}

function renderGiftSignItems(preview) {
  const items = preview?.envelope?.items ?? [];
  const box = $('#giftSignItems');
  if (!items.length) {
    box.innerHTML = `<p class="reassure" style="margin:0">
      There is nothing to sign yet. Go back and assign at least one thing to a person on your list, then come back.</p>`;
    return;
  }
  // Group by recipient for readability.
  const byId = new Map();
  for (const it of items) {
    const id = it.assigned_to?.heir_id;
    if (!byId.has(id)) byId.set(id, { name: it.assigned_to?.name || 'Someone', rel: it.assigned_to?.relationship, kind: it.assigned_to?.recipient_type || 'heir', rows: [] });
    byId.get(id).rows.push(it);
  }
  const groups = [...byId.values()];
  box.innerHTML = groups.map((g) => {
    const kindLabel = g.kind === 'named_recipient' ? ' <span class="kind-badge">Named recipient</span>' : '';
    return `
      <div class="sign-group">
        <div class="sign-group-h">${escapeHtml(g.name)}${g.rel ? ` <span class="personrel">${escapeHtml(g.rel)}</span>` : ''}${kindLabel}</div>
        <ol class="sign-list">
          ${g.rows.map((it) => {
            // The envelope emits items as { id, name, room, ... }. The
            // registry's item list endpoint uses { title, room_name }.
            // Support both so the sign screen renders correctly whether
            // it is fed a preview or a raw list.
            const label = it.name || it.title || 'Untitled item';
            const roomName = it.room?.name || it.room_name || '';
            return `<li>${escapeHtml(label)}${roomName ? ` <span class="personrel">${escapeHtml(roomName)}</span>` : ''}</li>`;
          }).join('')}
        </ol>
      </div>`;
  }).join('');
}

$('#giftSignCancel').onclick = () => go('gifts');

$('#giftSignGo').onclick = async () => {
  const ack = $('#giftSignerAck').value.trim();
  // The dropdown labelled "Who is holding your will?" is populated from
  // the wills_caretakers endpoint. Send it as caretaker_ids, not
  // trustee_id \u2014 the server treats those as different tables.
  const caretakerId = $('#giftSignerTrustee').value.trim();
  $('#giftSignError').hidden = true;

  // Validate the "type the phrase" evidence. We accept any case so the
  // owner is not blocked by a stray shift-key, but the words themselves
  // must match \u2014 that is the whole point of the acknowledgement.
  // One box, not two: the typed phrase itself is the confirmation.
  // The owner's identity is already established by the account; the
  // printed paper carries their handwritten name.
  if (ack.toLowerCase() !== 'these are my wishes today') {
    setSignError('Please type the phrase exactly: These are my wishes today');
    return;
  }
  const items = giftsState.preview?.envelope?.items ?? [];
  if (!items.length) { setSignError('There is nothing to confirm yet.'); return; }

  // A confirmation before an irreversible action, in plain words.
  if (!confirm(`Confirm your list of special gifting with these ${items.length} item${items.length === 1 ? '' : 's'}?\n\nA new version will be filed with today's date. You can always come back and confirm a new version \u2014 the newest one is the one that counts.`)) return;

  try {
    // The server route expects a structured `signature` object; the
    // typed-in acknowledgement is our evidence field.
    const res = await api('/api/two-outputs/addendum/sign', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        owner_participant_id: REGISTRY_OWNER_PARTICIPANT_ID,
        caretaker_ids: caretakerId ? [caretakerId] : [],
        signature: {
          // `device` is what the server requires as its minimum piece of
          // wet-ink evidence. We pass the browser user agent, so the
          // signed record shows what the owner was confirming on.
          device: navigator.userAgent || 'unknown',
          acknowledgement: ack,
          signed_at: new Date().toISOString(),
        },
      }),
    });
    toast(`Confirmed. Version ${res.version_number ?? 1} is on file.`);
    await loadGifts();
    go('giftversions');
  } catch (e) {
    setSignError(e.message);
  }
};

function setSignError(msg) {
  const el = $('#giftSignError');
  el.textContent = msg;
  el.hidden = false;
}

/* ---- Version history ---- */

async function loadGiftVersions() {
  try {
    const res = await api(`/api/two-outputs/addendum/versions?owner_participant_id=${encodeURIComponent(REGISTRY_OWNER_PARTICIPANT_ID)}`);
    const versions = res.versions ?? [];
    const empty = $('#giftVersionsEmpty');
    const list = $('#giftVersionsList');
    const offer = $('#emailPreviewOffer');
    if (!versions.length) {
      empty.hidden = false;
      list.innerHTML = '';
      if (offer) offer.hidden = true;
      return;
    }
    empty.hidden = true;
    await renderEmailPreviewOffer(versions);
    // Newest first; the current one is the newest that isn't superseded.
    // The store returns versions in some order; we sort newest-first by
    // signed_at and treat the highest version_number as current.
    const sorted = versions.slice().sort((a, b) =>
      (b.signed_at || '').localeCompare(a.signed_at || ''));
    const highest = Math.max(...sorted.map((v) => Number(v.version_number || 0)));
    list.innerHTML = sorted.map((v) => {
      const isCurrent = Number(v.version_number) === highest;
      const when = v.signed_at ? new Date(v.signed_at).toLocaleString() : 'unknown date';
      // Signed versions carry the item list under items_snapshot. There is
      // no separate "counts" block on version rows; we derive item count
      // from the snapshot length. The typed acknowledgement lives under
      // signature_evidence.acknowledgement ("These are my wishes today") \u2014
      // that is what the owner typed, and it is what stands in for a
      // handwritten signature at the moment of confirmation.
      const count = Array.isArray(v.items_snapshot) ? v.items_snapshot.length : (v.item_count ?? '\u2014');
      return `
        <div class="version-row ${isCurrent ? 'current' : 'superseded'}">
          <div class="version-h">
            <span class="version-v">Version ${escapeHtml(String(v.version_number || '?'))}</span>
            ${isCurrent ? '<span class="badge current">Current</span>' : '<span class="badge superseded">Superseded</span>'}
          </div>
          <div class="version-meta">Confirmed ${escapeHtml(when)}</div>
          <div class="version-meta">${count} item${count === 1 ? '' : 's'} covered</div>
          <button class="ghost wide" data-download="${escapeHtml(v.version_id || '')}">Download this version</button>
        </div>`;
    }).join('');
    $$('#giftVersionsList [data-download]').forEach((b) => {
      b.onclick = () => window.open(`/api/two-outputs/addendum/versions/${encodeURIComponent(b.dataset.download)}/file`, '_blank');
    });
  } catch (e) {
    toast(`Could not load past versions: ${e.message}`, true);
  }
}

/**
 * Populate the "Send an unsigned preview by email" offer block on the
 * versions screen.
 *
 * We only show the offer when:
 *   1. There is a current signed version that is not frozen (a frozen
 *      version means the trustee has already been handed the memorandum;
 *      re-sending a preview after that would confuse everyone).
 *   2. There is at least one wills caretaker on file with an email address
 *      AND delivery_method === 'email'. Caretakers set to signed_link or
 *      print_mail do not appear \u2014 they haven't asked for email delivery.
 *
 * The server also enforces both of those rules; this UI branch is just so
 * an elderly user is not offered a button that will refuse them.
 */
async function renderEmailPreviewOffer(versions) {
  const offer = $('#emailPreviewOffer');
  if (!offer) return;
  const highest = Math.max(...versions.map((v) => Number(v.version_number || 0)));
  const current = versions.find((v) => Number(v.version_number) === highest);
  if (!current || current.frozen_at) { offer.hidden = true; return; }
  let caretakers = [];
  try {
    const res = await api('/api/two-outputs/wills-caretakers');
    caretakers = (res.wills_caretakers ?? []).filter((c) =>
      c.delivery_method === 'email' && String(c.email || '').trim());
  } catch { caretakers = []; }
  if (!caretakers.length) { offer.hidden = true; return; }
  const sel = $('#emailPreviewRecipient');
  sel.innerHTML = caretakers.map((c) => {
    const label = c.firm ? `${c.name} (${c.firm}) \u2014 ${c.email}` : `${c.name} \u2014 ${c.email}`;
    return `<option value="${escapeHtml(c.caretaker_id)}">${escapeHtml(label)}</option>`;
  }).join('');
  offer.hidden = false;
  const btn = $('#emailPreviewSend');
  btn.onclick = async () => {
    const caretakerId = sel.value;
    if (!caretakerId) return;
    const chosen = caretakers.find((c) => c.caretaker_id === caretakerId);
    const label = chosen ? (chosen.firm ? `${chosen.name} (${chosen.firm})` : chosen.name) : 'this recipient';
    // Confirm because this is an outbound email \u2014 not irreversible in
    // any real sense, but the user should mean it.
    const okToSend = confirm(
      `Send an UNSIGNED PREVIEW of version ${current.version_number} to ${label}?\n\n` +
      `This is a courtesy, not a filing. The paper you sign by hand and get to them is what carries the weight.`
    );
    if (!okToSend) return;
    btn.disabled = true;
    try {
      const out = await api('/api/two-outputs/addendum/email-preview', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          owner_participant_id: REGISTRY_OWNER_PARTICIPANT_ID,
          caretaker_id: caretakerId,
        }),
      });
      toast(`Unsigned preview sent to ${out.recipient?.name || label}.`);
    } catch (e) {
      toast(`Could not send preview: ${e.message}`, true);
    } finally {
      btn.disabled = false;
    }
  };
}

/**
 * Find-or-create an heir by name, then assign the item to that heir.
 * Called from the capture flow when the owner ticks "Add this to my
 * special gifts". Falls back gracefully if the roster call fails \u2014
 * a broken addendum lookup must never break the item save.
 *
 * NOTE: this always creates the recipient as recipient_type='heir'.
 * The owner can promote to 'named_recipient' from the Special gifts
 * screen later. Doing it that way keeps the capture flow simple: one
 * screen, one question.
 */
async function assignItemToNamedRecipient(itemId, name, relationship) {
  const clean = String(name || '').trim();
  if (!clean) return;
  // Look for an existing heir by (case-insensitive) name.
  const list = await api('/api/two-outputs/heirs');
  const existing = (list.heirs || []).find(
    (h) => h.name.toLowerCase() === clean.toLowerCase(),
  );
  let heirId = existing?.heir_id;
  if (!heirId) {
    const created = await api('/api/two-outputs/heirs', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        name: clean,
        relationship: (relationship || '').trim(),
        recipient_type: 'heir',
      }),
    });
    heirId = created.heir_id;
  }
  await api(`/api/items/${itemId}/assign`, {
    method: 'PATCH', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ heir_id: heirId }),
  });
}

/**
 * Show/hide the "Add to my special gifts" block based on whether the
 * owner has typed or picked a name. Also updates the inline "puts <who>
 * and this item onto the memorandum" hint so the phrasing is concrete.
 */
function updateGiftBlockVisibility() {
  const block = $('#capGiftBlock');
  const who = $('#capGiftWho');
  const nameEl = $('#capRecipient');
  if (!block || !nameEl) return;
  const name = nameEl.value.trim();
  block.hidden = !name;
  if (who) who.textContent = name || 'this person';
}

// Wire up on load. The step becomes visible only when the owner reaches
// step 7, but the input is always in the DOM so `input` fires anywhere.
document.addEventListener('DOMContentLoaded', () => {
  const el = $('#capRecipient');
  if (el) el.addEventListener('input', updateGiftBlockVisibility);
}, { once: true });

/* ================================================================== */
/* Slice B \u2014 the memorandum writer.                                  */
/*                                                                     */
/* One place per partner to say who-gets-what. In couple mode each     */
/* partner has their own memorandum; this screen shows the caller     */
/* their own, and surfaces conflicts against the partner's latest.    */
/* The server does the heavy lifting \u2014 identity, versioning, and       */
/* conflict detection. This client only paints and gathers input.     */
/* ================================================================== */

/*
 * All memorandum-related state in one object so it's easy to reset
 * and easy to reason about while stepping through the screen. The
 * roster and item list are cached across mounts so the entry editor
 * opens instantly; loadMemo() refreshes them.
 */
const memoState = {
  draft: null,           // { participant_id, version, is_signed, entries: [...] }
  versions: [],          // list of my past signed versions
  partner: null,         // { participant_id, display_name } or null
  partnerLatest: null,   // partner's most recent signed version or null
  conflicts: [],         // raw conflicts array from /api/memorandum
  householdMode: 'solo',
  heirs: [],             // shared roster (heirs + named recipients)
  items: [],             // /api/items list, used by the item picker
  editing: null,         // in-flight entry being edited, or null for add
  pickedItemId: null,    // selection in the item picker
  pickedHeirId: null,    // selection in the heir chips
};

/*
 * Load everything the screen needs in parallel. Three independent GETs:
 *   \u2022 /api/memorandum          my draft, my versions, partner info, conflicts
 *   \u2022 /api/two-outputs/heirs   the roster (heirs + named recipients)
 *   \u2022 /api/items               the item list, for titles + the picker
 *
 * Each fetch tolerates its own failure so a slow items query does not
 * blank the whole screen. Errors are surfaced as toasts, not modals
 * \u2014 an elderly owner should never see a blocking dialog on mount.
 */
async function loadMemo() {
  try {
    const [memoRes, heirsRes, itemsRes] = await Promise.all([
      api('/api/memorandum'),
      api('/api/two-outputs/heirs').catch(() => ({ heirs: [] })),
      api('/api/items').catch(() => ({ items: [] })),
    ]);
    memoState.draft = memoRes.my_draft;
    memoState.versions = memoRes.my_versions ?? [];
    memoState.partner = memoRes.partner;
    memoState.partnerLatest = memoRes.partner_latest_signed;
    memoState.conflicts = memoRes.conflicts ?? [];
    memoState.householdMode = memoRes.household_mode || 'solo';
    memoState.heirs = heirsRes.heirs ?? [];
    memoState.items = itemsRes.items ?? [];
    renderMemo();
  } catch (e) {
    toast(`Could not open your memorandum: ${e.message}`, true);
  }
}

/*
 * Format the version chip.
 *   \u2022 v1 empty draft   \u2192 "Draft v1"
 *   \u2022 v2 signed        \u2192 "Signed v2 \u00b7 Aug 9, 2026"
 *   \u2022 vN unsigned      \u2192 "Draft v{N} \u2014 not yet signed"
 */
function memoVersionLabel() {
  const d = memoState.draft;
  if (!d) return '';
  if (d.is_signed) {
    const when = d.signed_at ? new Date(d.signed_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '';
    return `Signed v${d.version}${when ? ' \u00b7 ' + when : ''}`;
  }
  if (d.version > 1) return `Draft v${d.version} \u2014 not yet signed`;
  return 'Draft \u2014 not yet signed';
}

/*
 * Look up an item title by id from the cached items list. Falls back to a
 * short placeholder if the item was removed since the memorandum was written.
 */
function memoItemLabel(itemId) {
  const it = memoState.items.find((i) => i.item_id === itemId);
  if (!it) return '(item no longer on your list)';
  return it.title || NO_TITLE;
}

function memoItemRoomLabel(itemId) {
  const it = memoState.items.find((i) => i.item_id === itemId);
  return it?.room?.name || '';
}

/*
 * Look up a heir/named recipient by heir_id. Returns the name only.
 * Used both for entry rows and the conflict banner.
 */
function memoHeirLabel(heirId) {
  const h = memoState.heirs.find((x) => x.heir_id === heirId);
  if (!h) return '(person removed)';
  return h.name || '(unnamed)';
}

/*
 * Paint the whole writer screen from memoState. Called after every mount
 * and after every save/delete. Keep this idempotent so re-render is safe.
 */
function renderMemo() {
  const d = memoState.draft;
  // Page title uses the same plain-language label in both modes; the sub
  // line changes to reflect the couple-mode reality that partners keep
  // separate lists.
  $('#memoTitle').textContent = 'Specific gifts by name';
  $('#memoSub').textContent = memoState.householdMode === 'couple'
    ? 'Your personal list of who gets what. Your partner keeps a separate list.'
    : 'Tell your family which things go to particular people.';
  $('#memoVersion').textContent = memoVersionLabel();

  // Post-signing-edit banner \u2014 shown only when we're on v2+ AND the
  // current draft is unsigned. Owner's own words, locked copy.
  const showEdit = d && !d.is_signed && d.version > 1;
  $('#memoEditNotice').hidden = !showEdit;

  // Conflict banner. Only shown when there are real conflicts against the
  // partner's LATEST SIGNED version. If the partner hasn't signed yet,
  // conflicts is empty by construction on the server.
  renderMemoConflicts();

  // The rows. Empty state uses a soft dashed card, never an error.
  const box = $('#memoList');
  const entries = d?.entries ?? [];
  if (!entries.length) {
    box.innerHTML = `<div class="memo-empty">Nothing on your list yet. Tap <b>Add specific gift by name</b> above to name the first one.</div>`;
  } else {
    // Build a set of item_ids in conflict for quick lookup on each row.
    const conflictItemIds = new Set(memoState.conflicts.map((c) => c.item_id));
    box.innerHTML = entries.map((e) => {
      const inConflict = conflictItemIds.has(e.item_id);
      const heirName = e.assigned_to_heir_id ? memoHeirLabel(e.assigned_to_heir_id) : '(nobody named)';
      const room = memoItemRoomLabel(e.item_id);
      return `
        <button class="memo-row${inConflict ? ' conflict' : ''}" data-entry="${escapeHtml(e.entry_id)}">
          <span class="memo-row-item">${escapeHtml(memoItemLabel(e.item_id))}</span>
          <span class="memo-row-heir">For ${escapeHtml(heirName)}${room ? ` \u00b7 ${escapeHtml(room)}` : ''}</span>
          ${e.note ? `<span class="memo-row-note">\u201c${escapeHtml(e.note)}\u201d</span>` : ''}
          ${inConflict ? `<span class="memo-row-flag">Sort out</span>` : `<span class="memo-row-arrow">\u203a</span>`}
        </button>`;
    }).join('');
    $$('#memoList .memo-row').forEach((b) => {
      b.onclick = () => openMemoEntry(b.dataset.entry);
    });
  }

  // Footer buttons. The versions link only appears once at least one
  // version has been signed, otherwise there's nothing to look at.
  // memoState.versions comes from the server and includes the current
  // in-flight draft, so filter to entries that were actually signed.
  const hasSigned = memoState.versions.some((v) => v.is_signed === true || v.is_signed === 1);
  const versionsBtn = $('#memoVersionsBtn');
  versionsBtn.hidden = !hasSigned;
  versionsBtn.style.display = hasSigned ? '' : 'none';

  // The primary action \u2014 "Print and sign" \u2014 is only meaningful when
  // there is at least one entry with a person named. Otherwise it's a
  // dead-end, so we disable it and tell the owner why in the label.
  const canSign = entries.some((e) => !!e.assigned_to_heir_id);
  const signBtn = $('#memoSignBtn');
  signBtn.disabled = !canSign;
  signBtn.textContent = canSign ? 'Print and sign' : 'Print and sign \u2014 add at least one first';
}

/*
 * Paint the gold conflict banner from memoState.conflicts. Copy is firm
 * but soft \u2014 the app never blocks signing; the trustee and the will
 * reading can still resolve everything. This banner only strongly
 * advises resolution before printing.
 */
function renderMemoConflicts() {
  const banner = $('#memoConflictBanner');
  const list = $('#memoConflictList');
  const conflicts = memoState.conflicts;
  if (!conflicts.length) { banner.hidden = true; return; }
  banner.hidden = false;
  const partnerName = memoState.partner?.display_name || 'your partner';
  const withWhom = memoState.partner?.display_name ? `with ${partnerName}` : 'with your partner';
  $('#memoConflictPartner').textContent = partnerName;
  $('#memoConflictH').textContent = conflicts.length === 1
    ? `One thing to sort out ${withWhom}`
    : `${conflicts.length} things to sort out ${withWhom}`;
  list.innerHTML = conflicts.map((c) => {
    const itemLabel = memoItemLabel(c.item_id);
    const myHeir = memoHeirLabel(c.participant_a_heir_id);
    const theirHeir = memoHeirLabel(c.participant_b_heir_id);
    return `<li><b>${escapeHtml(itemLabel)}</b> \u2014 you named <b>${escapeHtml(myHeir)}</b>, ${escapeHtml(partnerName)} named <b>${escapeHtml(theirHeir)}</b>.</li>`;
  }).join('');
}

/* ---------------------------- entry editor ----------------------- */

/*
 * Fresh-slate the entry editor. Called by go('memoentry') on a plain
 * navigation \u2014 the \`editing\` flag is set by openMemoEntry() when we
 * come in for an edit, and go() honours it by skipping this reset.
 */
function resetMemoEntry() {
  memoState.editing = null;
  memoState.pickedItemId = null;
  memoState.pickedHeirId = null;
  $('#memoEntryHeading').textContent = 'Add specific gift by name';
  $('#memoEntryItemSearch').value = '';
  $('#memoEntryItemPicked').hidden = true;
  $('#memoEntryNote').value = '';
  $('#memoEntryNoteCount').textContent = '0';
  // The Remove button is only meaningful when editing an existing row.
  // hidden=true on a button with an explicit inline style set elsewhere
  // will not always suffice, so wipe display too.
  const removeBtn = $('#memoEntryRemove');
  removeBtn.hidden = true;
  removeBtn.style.display = 'none';
  $('#memoEntryError').hidden = true;
  renderMemoEntryPickers();
}

/*
 * Open the editor for an existing entry. Looks the entry up from the
 * cached draft, fills the fields, shows the Remove button, and jumps
 * to the memoentry screen with the editing flag so go() doesn't reset.
 */
function openMemoEntry(entryId) {
  const entry = (memoState.draft?.entries ?? []).find((e) => e.entry_id === entryId);
  if (!entry) { toast('Could not find that entry \u2014 it may have been removed.', true); return; }
  memoState.editing = entry;
  memoState.pickedItemId = entry.item_id;
  memoState.pickedHeirId = entry.assigned_to_heir_id;
  go('memoentry', { editing: true });
  $('#memoEntryHeading').textContent = 'Edit this promise';
  $('#memoEntryItemSearch').value = '';
  $('#memoEntryNote').value = entry.note || '';
  $('#memoEntryNoteCount').textContent = String((entry.note || '').length);
  const removeBtn = $('#memoEntryRemove');
  removeBtn.hidden = false;
  removeBtn.style.display = '';
  $('#memoEntryError').hidden = true;
  renderMemoEntryPickers();
}

/*
 * Render both pickers: the item list (filtered by the search box) and
 * the heir chips. Also paints the "already picked" summary card once
 * the owner has chosen an item so the picker can scroll away.
 */
function renderMemoEntryPickers() {
  const search = ($('#memoEntryItemSearch').value || '').trim().toLowerCase();
  const box = $('#memoEntryItemList');
  const picked = memoState.pickedItemId;

  // Filter items. We include only "kept" items \u2014 the ones the owner has
  // decided to record. Rejected items should never show up in a promise.
  const kept = memoState.items.filter((i) => (i.review_state || 'kept') !== 'rejected');
  const list = search
    ? kept.filter((i) => (i.title || '').toLowerCase().includes(search))
    : kept;

  if (picked) {
    const it = memoState.items.find((i) => i.item_id === picked);
    const label = it?.title || memoItemLabel(picked);
    const room = it?.room?.name || '';
    $('#memoEntryItemPicked').hidden = false;
    $('#memoEntryItemPicked').innerHTML =
      `<b>${escapeHtml(label)}</b>${room ? ` \u00b7 ${escapeHtml(room)}` : ''}<button class="linky change" id="memoEntryChangeItem" type="button">Change</button>`;
    box.hidden = true;
    $('#memoEntryItemSearch').hidden = true;
    const changeBtn = $('#memoEntryChangeItem');
    if (changeBtn) changeBtn.onclick = () => {
      memoState.pickedItemId = null;
      renderMemoEntryPickers();
    };
  } else {
    $('#memoEntryItemPicked').hidden = true;
    box.hidden = false;
    $('#memoEntryItemSearch').hidden = false;
    if (!list.length) {
      box.innerHTML = `<div class="pickrow" style="cursor:default">No items match. Try a different word, or add the item first from the Home screen.</div>`;
    } else {
      box.innerHTML = list.slice(0, 40).map((i) => `
        <button type="button" class="pickrow" data-item="${escapeHtml(i.item_id)}">
          ${escapeHtml(i.title || NO_TITLE)}
          <span class="pickrow-sub">${escapeHtml(i.room?.name || 'No room')}${i.category?.name ? ` \u00b7 ${escapeHtml(i.category.name)}` : ''}</span>
        </button>`).join('');
      $$('#memoEntryItemList .pickrow[data-item]').forEach((b) => {
        b.onclick = () => {
          memoState.pickedItemId = b.dataset.item;
          renderMemoEntryPickers();
        };
      });
    }
  }

  // Heir chips. Same roster shape as the old gifts screen \u2014 heirs and
  // named recipients side by side. Named recipients get a small tag so
  // the owner can tell friends apart from will-heirs at a glance.
  const chipsBox = $('#memoEntryHeirChips');
  const emptyMsg = $('#memoEntryHeirEmpty');
  if (!memoState.heirs.length) {
    chipsBox.innerHTML = '';
    emptyMsg.hidden = false;
    const addBtn = $('#memoEntryHeirsAdd');
    if (addBtn) addBtn.onclick = () => go('gifts');
  } else {
    emptyMsg.hidden = true;
    chipsBox.innerHTML = memoState.heirs.map((h) => {
      const selected = h.heir_id === memoState.pickedHeirId;
      const kind = (h.recipient_type || 'heir') === 'heir' ? '' : ' \u00b7 named';
      return `<button type="button" class="chip" aria-pressed="${selected ? 'true' : 'false'}" data-heir="${escapeHtml(h.heir_id)}">${escapeHtml(h.name)}${escapeHtml(kind)}</button>`;
    }).join('');
    $$('#memoEntryHeirChips [data-heir]').forEach((b) => {
      b.onclick = () => {
        memoState.pickedHeirId = b.dataset.heir;
        renderMemoEntryPickers();
      };
    });
  }
}

/*
 * Save the currently-being-edited entry. Upserts against
 * /api/memorandum/entries and re-loads the whole screen so version
 * bumps and conflict changes are reflected immediately.
 */
async function saveMemoEntry() {
  const err = $('#memoEntryError');
  err.hidden = true;
  if (!memoState.pickedItemId) {
    err.textContent = 'Please pick which item this is about.';
    err.hidden = false;
    return;
  }
  const note = ($('#memoEntryNote').value || '').trim();
  const body = {
    item_id: memoState.pickedItemId,
    assigned_to_heir_id: memoState.pickedHeirId || null,
    note,
  };
  try {
    await api('/api/memorandum/entries', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    toast('Saved.');
    await loadMemo();
    go('memo', { back: true });
  } catch (e) {
    err.textContent = e.message || 'Could not save just now. Nothing was changed.';
    err.hidden = false;
  }
}

/*
 * Delete the entry the owner is editing. No confirm dialog on the
 * detail screen itself \u2014 there is a big Remove button; if that was
 * a slip they can add it back in ten seconds. We only confirm
 * on sign because signing is the irreversible step.
 */
async function removeMemoEntry() {
  const editing = memoState.editing;
  if (!editing) return;
  try {
    await api(`/api/memorandum/entries/${encodeURIComponent(editing.entry_id)}`, { method: 'DELETE' });
    toast('Taken off your list.');
    await loadMemo();
    go('memo', { back: true });
  } catch (e) {
    const err = $('#memoEntryError');
    err.textContent = e.message || 'Could not remove that just now.';
    err.hidden = false;
  }
}

/* ---------------------------- wiring ----------------------------- */

$('#memoAddBtn').onclick = () => go('memoentry');
$('#memoEntrySave').onclick = saveMemoEntry;
$('#memoEntryCancel').onclick = () => go('memo', { back: true });
$('#memoEntryRemove').onclick = removeMemoEntry;
$('#memoEntryItemSearch').addEventListener('input', renderMemoEntryPickers);
$('#memoEntryNote').addEventListener('input', (e) => {
  $('#memoEntryNoteCount').textContent = String((e.target.value || '').length);
});

/*
 * "Print and sign" and "Past signed versions" are placeholders in Slice B \u2014
 * step 6 (sign flow with modified confirm dialog) and step 7 (PDF template)
 * will wire the real destinations. For now they route to the existing
 * giftsign / giftversions screens so the buttons don't dead-end mid-slice.
 */
$('#memoSignBtn').onclick = () => {
  toast('The sign flow lands next step. For now, use the older screen.');
  go('giftsign');
};
$('#memoVersionsBtn').onclick = () => go('giftversions');

/* ================================================================== */
/* Slice 4 \u2014 household link screen.                                 */
/*                                                                     */
/* The screen does its own fetch on mount rather than subscribing to a */
/* shared cache. Household state is small; a re-fetch on every screen  */
/* open costs nothing and avoids stale UI after either partner acts    */
/* from a different tab.                                               */
/* ================================================================== */

/**
 * The household-link screen. Renders one of three states based on the
 * /household-link summary. Copy stays plain-language because the audience is
 * an elderly owner or their co-owner; every action confirms first.
 */
/**
 * The helper-invite screen. Simpler than the partner-link ceremony: an owner
 * sends a secure invite with role 'assistant'. Helpers can take photos and
 * document items but do not get their own memorandum and are not part of
 * conflict detection. There is no confirm/unlink step here — the owner can
 * revoke a helper's access from this same screen.
 */
async function loadHelperInvite() {
  const body = $('#helperInviteBody');
  if (!body) return;
  body.innerHTML = '<p class="reassure">Loading\u2026</p>';
  let s;
  try { s = await api('/api/household-link'); }
  catch (e) { body.innerHTML = `<p class="reassure">Could not load: ${escapeHtml(e.message)}</p>`; return; }

  const me = (s.participants || []).find((p) => p.is_me);
  const isOwner = me && (me.role === 'owner' || me.role === 'bootstrap-owner');
  const isPartner = me && me.role === 'partner';
  const canManageHelpers = isOwner || isPartner;
  const assistants = s.assistants || [];

  if (!canManageHelpers) {
    body.innerHTML = `
      <h2>Invite a helper</h2>
      <p class="lede">Only the owner or a co-owner can invite a helper. Ask them to send you the invitation.</p>
    `;
    return;
  }

  // Show existing helpers + invite form
  const helperList = assistants.length
    ? `<div class="link-card" style="margin-bottom:20px">
        <div><b>Helpers with access</b></div>
        <ul class="plain-list">
          ${assistants.map((a) => `<li>${escapeHtml(a.display_name || a.email)}</li>`).join('')}
        </ul>
      </div>`
    : '';

  body.innerHTML = `
    <h2>Invite a helper</h2>
    <p class="lede">A helper can take photos and document items for you. They do not have their own gift list and are not part of any conflict checks. They will get an email with a secure, one-time sign-in link valid for twenty minutes.</p>
    ${helperList}
    <div class="invite-form">
      <label for="helperName">Their first name (optional)</label>
      <input id="helperName" type="text" autocomplete="given-name" placeholder="e.g., Sarah">
      <label for="helperEmail">Their email</label>
      <input id="helperEmail" type="email" autocomplete="email" placeholder="name@example.com">
      <button class="primary wide" id="helperInviteBtn">Send invite to helper</button>
    </div>
    <div id="helperInviteResult" hidden></div>
    <p class="reassure">This only gives them access to help document your items. You can revoke access anytime. Nothing here is a will.</p>
    <button class="ghost wide" data-go="home">Back to home</button>
  `;

  $('#helperInviteBtn').onclick = async () => {
    const email = $('#helperEmail').value.trim();
    const display_name = $('#helperName').value.trim();
    if (!email) { toast('Type their email.', true); return; }
    if (!confirm(`Send the helper invite to ${email}?`)) return;
    try {
      const out = await api('/api/household-link/invite', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ email, display_name, role: 'assistant' }),
      });
      const box = $('#helperInviteResult');
      box.hidden = false;
      box.innerHTML = out.link
        ? `<p class="reassure">Invitation sent. For development, the sign-in link is:<br><code class="invite-link">${escapeHtml(out.link)}</code></p>`
        : `<p class="reassure">Helper invite sent to ${escapeHtml(email)}. Ask them to check their inbox; the link expires in twenty minutes.</p>`;
      toast('Helper invite sent.');
      // Refresh the helper list
      loadHelperInvite();
    } catch (e) { toast(e.message, true); }
  };
}

async function loadHouseholdLink() {
  const body = $('#householdLinkBody');
  if (!body) return;
  body.innerHTML = '<p class="reassure">Loading\u2026</p>';
  let s;
  try { s = await api('/api/household-link'); }
  catch (e) { body.innerHTML = `<p class="reassure">Could not load: ${escapeHtml(e.message)}</p>`; return; }

  const isCouple = s.household_mode === 'couple';
  const partnerPresent = !!s.partner_present;
  const canConfirm = !!s.can_confirm;
  const canUnlink = !!s.can_unlink;
  const me = (s.participants || []).find((p) => p.is_me);
  const isOwner = me && (me.role === 'owner' || me.role === 'bootstrap-owner');
  const partner = (s.participants || []).find((p) => !p.is_me);
  const assistants = s.assistants || [];
  const partners = s.partners || [];

  if (isCouple) {
    body.innerHTML = `
      <h2>Linked</h2>
      <p class="lede">You and ${escapeHtml((partner?.display_name || partner?.email) || 'your co-owner')} are linked. You share one inventory. Either of you can add items, tag them Important, and record where they should go.</p>
      <div class="link-card">
        <div><b>Linked on</b> ${s.linked_at ? new Date(s.linked_at).toLocaleDateString() : '\u2014'}</div>
        <div><b>Participants</b></div>
        <ul class="plain-list">
          ${(s.participants || []).map((p) => `<li>${escapeHtml(p.display_name || p.email || '')}${p.is_me ? ' <span class="badge who">you</span>' : ''}${p.role === 'owner' || p.role === 'bootstrap-owner' ? ' <span class="badge kept">owner</span>' : ''}</li>`).join('')}
        </ul>
      </div>
      <div class="detrow">
        ${canUnlink ? '<button class="ghost" id="unlinkBtn">Unlink</button>' : ''}
      </div>
      <p class="reassure">Unlinking goes back to a one-person view. Everything you recorded together stays on record.</p>
      ${assistants.length ? `
      <div class="link-card" style="margin-top:20px">
        <div><b>Helpers (${assistants.length}/10)</b></div>
        <ul class="plain-list">
          ${assistants.map((a) => `<li>${escapeHtml(a.display_name || a.email)}</li>`).join('')}
        </ul>
      </div>` : ''}
      ${isOwner || me?.role === 'partner' ? `
      <div class="invite-form" style="margin-top:20px">
        <h3>Add a helper</h3>
        <label for="helperName2">Their first name (optional)</label>
        <input id="helperName2" type="text" autocomplete="given-name" placeholder="e.g., Sarah">
        <label for="helperEmail2">Their email</label>
        <input id="helperEmail2" type="email" autocomplete="email" placeholder="name@example.com">
        <button class="primary wide" id="helperInviteBtn2">Send helper invite</button>
      </div>
      <div id="helperResult2" hidden></div>` : ''}
      <button class="ghost wide" data-go="home" style="margin-top:16px">Back to home</button>
    `;
    const unlink = $('#unlinkBtn');
    if (unlink) unlink.onclick = async () => {
      if (!confirm('Unlink? You can link again later. Everything you recorded together stays on record.')) return;
      try { await api('/api/household-link/unlink', { method: 'POST' }); toast('Unlinked.'); loadHouseholdLink(); }
      catch (e) { toast(e.message, true); }
    };
    const hBtn = $('#helperInviteBtn2');
    if (hBtn) hBtn.onclick = async () => {
      const email = $('#helperEmail2').value.trim();
      const display_name = $('#helperName2').value.trim();
      if (!email) { toast('Type their email.', true); return; }
      if (!confirm(`Send the helper invite to ${email}?`)) return;
      try {
        const out = await api('/api/household-link/invite', {
          method: 'POST', headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ email, display_name, role: 'assistant' }),
        });
        const box = $('#helperResult2');
        box.hidden = false;
        box.innerHTML = out.link
          ? `<p class="reassure">Invitation sent. For development, the sign-in link is:<br><code class="invite-link">${escapeHtml(out.link)}</code></p>`
          : `<p class="reassure">Helper invite sent to ${escapeHtml(email)}. Ask them to check their inbox; the link expires in twenty minutes.</p>`;
        toast('Helper invite sent.');
        loadHouseholdLink();
      } catch (e) { toast(e.message, true); }
    };
    return;
  }

  if (partnerPresent && canConfirm) {
    const suggestedName = me?.display_name || '';
    body.innerHTML = `
      <h2>Confirm the link</h2>
      <p class="lede">${escapeHtml((partner?.display_name || partner?.email) || 'Your co-owner')} has signed in. Confirming links the two of you. From then on, either of you can add items and record where they should go on a shared inventory.</p>
      <div class="invite-form">
        <label for="confirmName">Your first name (how you want to appear on this list)</label>
        <input id="confirmName" type="text" autocomplete="given-name" placeholder="e.g., Bob" value="${escapeHtml(suggestedName)}">
      </div>
      <div class="detrow">
        <button class="primary" id="confirmBtn">Confirm we are linked</button>
      </div>
      <p class="reassure">You can change your name later. You can also unlink later. Nothing here is a will.</p>
    `;
    $('#confirmBtn').onclick = async () => {
      if (!confirm('Confirm the link now? You can unlink later.')) return;
      const display_name = $('#confirmName').value.trim();
      try {
        await api('/api/household-link/confirm', {
          method: 'POST', headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ display_name }),
        });
        toast('Linked.'); loadHouseholdLink();
      } catch (e) { toast(e.message, true); }
    };
    return;
  }

  if (!isOwner) {
    body.innerHTML = `
      <h2>Not yet linked</h2>
      <p class="lede">Only the account owner can invite a co-owner. Ask them to open Reindeer Registry and send you the invitation email.</p>
    `;
    return;
  }

  // Solo mode, owner. Show unified invite page: co-owner + helpers
  body.innerHTML = `
    <h2>Add a co-owner or helper</h2>
    <p class="lede">Invite someone to join your Registry. A co-owner shares your inventory and keeps their own gift list. A helper can take photos and document items for you.</p>

    ${partners.length ? `
    <div class="link-card" style="margin-bottom:16px">
      <div><b>Co-owner (${partners.length}/1)</b></div>
      <ul class="plain-list">
        ${partners.map((p) => `<li>${escapeHtml(p.display_name || p.email)}</li>`).join('')}
      </ul>
    </div>` : ''}

    ${assistants.length ? `
    <div class="link-card" style="margin-bottom:16px">
      <div><b>Helpers (${assistants.length}/10)</b></div>
      <ul class="plain-list">
        ${assistants.map((a) => `<li>${escapeHtml(a.display_name || a.email)}</li>`).join('')}
      </ul>
    </div>` : ''}

    <div class="invite-form">
      <h3>Invite a co-owner</h3>
      <p class="reassure" style="margin-bottom:8px">Your legally bound partner. They will see everything you record and keep their own gift list. One co-owner maximum.</p>
      <label for="inviteName">Their first name (optional)</label>
      <input id="inviteName" type="text" autocomplete="given-name" placeholder="e.g., Bob">
      <label for="inviteEmail">Their email</label>
      <input id="inviteEmail" type="email" autocomplete="email" placeholder="name@example.com">
      <button class="primary wide" id="inviteBtn">Send co-owner invite</button>
    </div>
    <div id="inviteResult" hidden></div>

    <div class="invite-form" style="margin-top:24px">
      <h3>Invite a helper</h3>
      <p class="reassure" style="margin-bottom:8px">A helper can take photos and document items for you. They do not have their own gift list and are not part of any conflict checks. Up to 10 helpers.</p>
      <label for="helperName3">Their first name (optional)</label>
      <input id="helperName3" type="text" autocomplete="given-name" placeholder="e.g., Sarah">
      <label for="helperEmail3">Their email</label>
      <input id="helperEmail3" type="email" autocomplete="email" placeholder="name@example.com">
      <button class="primary wide" id="helperInviteBtn3">Send helper invite</button>
    </div>
    <div id="helperResult3" hidden></div>

    <p class="reassure" style="margin-top:16px">They will get an email with a secure, one-time sign-in link valid for twenty minutes. You can revoke access anytime. Nothing here is a will.</p>
    <button class="ghost wide" data-go="home" style="margin-top:8px">Back to home</button>
  `;

  $('#inviteBtn').onclick = async () => {
    const email = $('#inviteEmail').value.trim();
    const display_name = $('#inviteName').value.trim();
    if (!email) { toast('Type their email.', true); return; }
    if (!confirm(`Send the co-owner invite to ${email}?`)) return;
    try {
      const out = await api('/api/household-link/invite', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ email, display_name, role: 'partner' }),
      });
      const box = $('#inviteResult');
      box.hidden = false;
      box.innerHTML = out.link
        ? `<p class="reassure">Invitation sent. For development, the sign-in link is:<br><code class="invite-link">${escapeHtml(out.link)}</code></p>`
        : `<p class="reassure">Co-owner invite sent to ${escapeHtml(email)}. Ask them to check their inbox; the link expires in twenty minutes.</p>`;
      toast('Co-owner invite sent.');
      loadHouseholdLink();
    } catch (e) { toast(e.message, true); }
  };

  $('#helperInviteBtn3').onclick = async () => {
    const email = $('#helperEmail3').value.trim();
    const display_name = $('#helperName3').value.trim();
    if (!email) { toast('Type their email.', true); return; }
    if (!confirm(`Send the helper invite to ${email}?`)) return;
    try {
      const out = await api('/api/household-link/invite', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ email, display_name, role: 'assistant' }),
      });
      const box = $('#helperResult3');
      box.hidden = false;
      box.innerHTML = out.link
        ? `<p class="reassure">Invitation sent. For development, the sign-in link is:<br><code class="invite-link">${escapeHtml(out.link)}</code></p>`
        : `<p class="reassure">Helper invite sent to ${escapeHtml(email)}. Ask them to check their inbox; the link expires in twenty minutes.</p>`;
      toast('Helper invite sent.');
      loadHouseholdLink();
    } catch (e) { toast(e.message, true); }
  };
}

// ---------------------------------------------------------- Ship B: contested
/*
 * "Things families fight over" screen.
 *
 * Static, hand-written per-category advice. Each entry maps to a category
 * name the intake flow already knows (from DEFAULT_CATEGORIES seeded on
 * scope creation, or MORE_CATEGORIES the owner can promote). The `notice`
 * field is optional and reserved for firearms today — it renders as a
 * distinct call-out above the button so an owner cannot miss it. Firearms
 * still allows an assign action because some owners already know exactly
 * where each piece is meant to go; the notice is about legal responsibility,
 * not about hiding the flow.
 */
const CONTESTED_CATEGORIES = [
  { key: 'Jewelry', why: 'Everyone remembers a piece differently, and market value hides the story.',
    advice: 'Lay all your jewelry and watches out on a table together. Take a wide photo of the whole spread first, then close-ups of each piece. Do it once and it is done.' },
  { key: 'Holiday ornaments', why: 'Every family fights about who gets Grandma\u2019s ornaments.',
    advice: 'Bring the box out at the holiday. Photograph as you unwrap. Say aloud who gave you which ornament \u2014 the recording is the point.' },
  { key: 'Heirloom and special furniture', why: 'Big pieces are hard to move; who \u201cclaims\u201d them turns tense.',
    advice: 'Photograph the piece where it lives. Note the maker or the story on the back. Say who you hope will make room for it. This includes musical instruments and handmade pieces.' },
  { key: 'Collectibles \u2014 artwork, rare wine or spirits, vintage cars', why: 'Value is fuzzy and easy to argue about.',
    advice: 'Photograph each piece with a ruler or hand for scale. Note where you bought it and roughly when.' },
  { key: 'Guns', why: 'Firearms carry legal rules that vary by state. Document what you have \u2014 the transfer itself is outside this app.',
    advice: 'Record what you have and what you would like to happen to each piece. Photograph the piece with any serial visible.',
    notice: 'The legal transfer happens outside this app. Record what you have and what you would like to happen to each piece. Your attorney or trustee will handle the legal side.' },
  { key: 'Letters, Journals & Recipes', why: 'Written words are once-only. The person who reads them first shapes the story.',
    advice: 'Photograph the outside of the folder or box. You do not have to open every letter. Lay recipes out and photograph the ones in a hand you recognise. Say who you would like to keep them.' },
  { key: 'Photographs', why: 'Physical photos have one copy. Whoever gets the box gets the memory.',
    advice: 'Lay a stack out on the table by decade or by person. Photograph the group, then the ones with people you can name on the back. Digital copies prevent the old cruelty of fighting over a single print.' },
];

function renderContestedCards() {
  const wrap = $('#contestedCards');
  if (!wrap) return;
  wrap.innerHTML = CONTESTED_CATEGORIES.map((c, i) => `
    <article class="contested-card" data-idx="${i}">
      <h3>${escapeHtml(c.key)}</h3>
      <p class="why">${escapeHtml(c.why)}</p>
      <p class="advice">${escapeHtml(c.advice)}</p>
      ${c.notice ? `<div class="trustee-notice"><strong>A word about firearms.</strong> ${escapeHtml(c.notice)}</div>` : ''}
      <div class="detrow">
        <button class="primary contested-add" data-cat="${escapeHtml(c.key)}">Add ${escapeHtml(c.key)} items</button>
      </div>
    </article>
  `).join('');
  $$('#contestedCards .contested-add').forEach((btn) => {
    btn.onclick = () => {
      const name = btn.dataset.cat;
      // Start a fresh capture but seed the category. The capture screen's
      // renderCatChips picks this up and presses (or promotes) the chip.
      resetCapture();
      cap.category = name;
      go('capture');
    };
  });
}

/*
 * Holiday reminder picker.
 *
 * Renders a checkbox list from the server's vocabulary, ticks the
 * participant's saved picks, and posts the full replacement list on save.
 * The Registry itself never sends email; a Perplexity Computer scheduled
 * task reads reminder_prefs and dispatches on the right days.
 */
async function loadReminderPicker() {
  const wrap = $('#reminderPicker');
  if (!wrap) return;
  wrap.innerHTML = '<p class="reassure">Loading\u2026</p>';
  try {
    const data = await api('/api/reminders/holidays');
    const picked = new Set(data.picked || []);
    wrap.innerHTML = (data.vocabulary || []).map((h) => `
      <label class="reminder-row">
        <input type="checkbox" data-key="${escapeHtml(h.key)}" ${picked.has(h.key) ? 'checked' : ''}>
        <span>${escapeHtml(h.label)}</span>
      </label>
    `).join('');
    const saveBtn = $('#reminderSaveBtn');
    if (saveBtn) {
      saveBtn.onclick = async () => {
        const keys = $$('#reminderPicker input[type="checkbox"]:checked')
          .map((c) => c.dataset.key);
        try {
          await api('/api/reminders/holidays', {
            method: 'POST', headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ holidays: keys }),
          });
          toast(keys.length ? 'Reminders saved.' : 'Reminders turned off.');
        } catch (e) { toast(e.message, true); }
      };
    }
  } catch (e) {
    wrap.innerHTML = `<p class="reassure">Could not load: ${escapeHtml(e.message)}</p>`;
  }
}
