import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { MIGRATIONS } from '../migrations/index.js';

/** Crockford base32 ULID — sortable, stable across export and import. */
const B32 = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
export function ulid(now = Date.now()) {
  let ts = '';
  let t = now;
  for (let i = 0; i < 10; i++) {
    ts = B32[t % 32] + ts;
    t = Math.floor(t / 32);
  }
  const rnd = crypto.randomBytes(16);
  let rand = '';
  for (let i = 0; i < 16; i++) rand += B32[rnd[i] % 32];
  return ts + rand;
}

/**
 * Open a database, run pending migrations inside a transaction, and enforce
 * foreign keys. Used identically by Reindeer Registry and Reindeer: FairPlay;
 * only the file path and scope type differ.
 */
export function openDb(filePath) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const db = new Database(filePath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  runMigrations(db);
  return db;
}

function runMigrations(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    applied_at TEXT NOT NULL
  )`);
  const applied = new Set(db.prepare('SELECT id FROM schema_migrations').all().map((r) => r.id));
  const insert = db.prepare('INSERT INTO schema_migrations (id, name, applied_at) VALUES (?, ?, ?)');

  for (const m of MIGRATIONS) {
    if (applied.has(m.id)) continue;
    const apply = db.transaction(() => {
      db.exec(m.sql);
      insert.run(m.id, m.name, new Date().toISOString());
    });
    apply();
  }
}

/** Standard OS data directory, matching the existing Reindeer: FairPlay posture. */
export function defaultDataDir(appName) {
  const home = process.env.HOME || process.env.USERPROFILE || '.';
  if (process.env.REINDEER_DATA_DIR) return path.join(process.env.REINDEER_DATA_DIR, appName);
  if (process.platform === 'darwin') return path.join(home, 'Library', 'Application Support', appName);
  if (process.platform === 'win32') return path.join(process.env.APPDATA || home, appName);
  return path.join(home, '.local', 'share', appName);
}
