/**
 * Mail transport.
 *
 * Three transports, all behind the same interface:
 *   SmtpMailer     — real delivery through the owner's mail provider.
 *   ConsoleMailer  — development. Writes the message to disk, sends nothing.
 *   RecordingMailer— tests. Keeps messages in memory.
 *
 * The app boots with ConsoleMailer unless SMTP settings are present, so no
 * accidental email can ever leave a development machine.
 */
import fs from 'node:fs';
import path from 'node:path';

export class Mailer {
  async send() { throw new Error('Mailer.send is not implemented'); }
  get describe() { return 'unconfigured'; }
}

export class SmtpMailer extends Mailer {
  constructor(config) {
    super();
    this.config = config;
    this._transport = null;
  }

  async transport() {
    if (this._transport) return this._transport;
    const { default: nodemailer } = await import('nodemailer');
    this._transport = nodemailer.createTransport({
      host: this.config.host,
      port: this.config.port ?? 587,
      secure: this.config.secure ?? (this.config.port === 465),
      auth: this.config.user ? { user: this.config.user, pass: this.config.pass } : undefined,
    });
    return this._transport;
  }

  async verify() {
    try {
      await (await this.transport()).verify();
      return { ok: true };
    } catch (e) {
      return { ok: false, error: friendlySmtpError(e) };
    }
  }

  async send(message) {
    try {
      const info = await (await this.transport()).sendMail({
        from: this.config.from,
        to: message.to,
        cc: message.cc,
        subject: message.subject,
        text: message.text,
        html: message.html,
        attachments: message.attachments,
      });
      return { ok: true, message_id: info.messageId, accepted: info.accepted ?? [] };
    } catch (e) {
      return { ok: false, error: friendlySmtpError(e) };
    }
  }

  get describe() { return `SMTP ${this.config.host}:${this.config.port ?? 587} as ${this.config.from}`; }
}

export class ConsoleMailer extends Mailer {
  constructor(outDir) { super(); this.outDir = outDir; }

  async send(message) {
    fs.mkdirSync(this.outDir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const base = path.join(this.outDir, `mail-${stamp}`);
    fs.writeFileSync(`${base}.txt`,
      `To: ${[].concat(message.to).join(', ')}\nSubject: ${message.subject}\n\n${message.text}\n`);
    if (message.html) fs.writeFileSync(`${base}.html`, message.html);
    for (const a of message.attachments ?? []) {
      fs.writeFileSync(path.join(this.outDir, a.filename), a.content);
    }
    return { ok: true, message_id: `console:${stamp}`, accepted: [].concat(message.to), written_to: base };
  }

  get describe() { return `console mailer, writing to ${this.outDir} (nothing is actually sent)`; }
}

export class RecordingMailer extends Mailer {
  constructor() { super(); this.sent = []; this.failNext = null; }

  async send(message) {
    if (this.failNext) { const e = this.failNext; this.failNext = null; return { ok: false, error: e }; }
    this.sent.push(message);
    return { ok: true, message_id: `test:${this.sent.length}`, accepted: [].concat(message.to) };
  }

  get describe() { return 'recording mailer (tests)'; }
}

export function mailerFromEnv(env = process.env, fallbackDir = '/tmp/legacy-mail') {
  if (env.LEGACY_SMTP_HOST) {
    return new SmtpMailer({
      host: env.LEGACY_SMTP_HOST,
      port: env.LEGACY_SMTP_PORT ? Number(env.LEGACY_SMTP_PORT) : 587,
      secure: env.LEGACY_SMTP_SECURE === 'true',
      user: env.LEGACY_SMTP_USER,
      pass: env.LEGACY_SMTP_PASS,
      from: env.LEGACY_SMTP_FROM || env.LEGACY_SMTP_USER,
    });
  }
  return new ConsoleMailer(env.LEGACY_MAIL_DIR || fallbackDir);
}

function friendlySmtpError(e) {
  const code = e?.code ?? '';
  if (code === 'EAUTH') return 'The mail server rejected the username or password. If the account uses two-factor sign-in, an app password is usually required.';
  if (code === 'ECONNECTION' || code === 'ESOCKET') return 'The mail server could not be reached. Check the server address and port.';
  if (code === 'EMESSAGE' && /size/i.test(e.message)) return 'The mail server refused the message because it is too large. Send the package as a link instead.';
  if (code === 'ETIMEDOUT') return 'The mail server did not respond in time.';
  return e?.message ?? 'The message could not be sent.';
}
