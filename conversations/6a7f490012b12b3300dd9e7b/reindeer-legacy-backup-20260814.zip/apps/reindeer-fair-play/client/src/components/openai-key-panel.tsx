import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type KeyStatus = {
  set: boolean;
  preview: string | null;
  liveMode: boolean;
};

/**
 * Transparent OpenAI key component.
 *
 * Sits quietly below the sign-in form. If no key is set, shows a small
 * "Enable AI" link that expands into a key-entry field. If a key is set,
 * shows the masked preview and a "Manage" link to change or clear it.
 *
 * The key is stored encrypted on the server. It never leaves the machine
 * except as a direct call to OpenAI's API during item analysis.
 */
export function OpenAIKeyPanel({
  keyStatus,
}: {
  keyStatus: KeyStatus | undefined;
}) {
  const [expanded, setExpanded] = useState(false);
  const [keyInput, setKeyInput] = useState("");
  const [message, setMessage] = useState<string | null>(null);

  const saveKey = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PUT", "/api/settings/openai", {
        apiKey: keyInput,
      });
      return (await res.json()) as KeyStatus & { message?: string };
    },
    onSuccess: (data) => {
      setMessage(data.message ?? null);
      setKeyInput("");
      setExpanded(false);
      queryClient.invalidateQueries({ queryKey: ["/api/settings/openai"] });
    },
    onError: (e: Error) => {
      setMessage(e.message.replace(/^\d+:\s*/, ""));
    },
  });

  // Collapsed state: a quiet line below the sign-in card
  if (!expanded && !keyStatus?.set) {
    return (
      <div className="mt-6 text-center">
        <button
          type="button"
          className="text-xs text-muted-foreground underline underline-offset-2 hover:text-foreground"
          onClick={() => setExpanded(true)}
          data-testid="button-enable-ai"
        >
          Enable AI categorization
        </button>
      </div>
    );
  }

  if (!expanded && keyStatus?.set) {
    return (
      <div className="mt-6 text-center text-xs text-muted-foreground">
        AI is <span className="font-medium text-foreground">live</span> ({keyStatus.preview})
        <button
          type="button"
          className="ml-2 underline underline-offset-2 hover:text-foreground"
          onClick={() => setExpanded(true)}
          data-testid="button-manage-ai-key"
        >
          Manage
        </button>
      </div>
    );
  }

  // Expanded state: key entry form
  return (
    <Card className="mt-4" data-testid="card-openai-key">
      <CardContent className="space-y-4 p-6">
        <div>
          <h2 className="font-serif text-lg font-semibold" data-testid="text-ai-key-title">
            OpenAI API Key
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Paste your OpenAI API key to enable live AI categorization and value estimates.
            Without a key, the app uses a built-in mock mode that still works but won't
            have real AI intelligence.
          </p>
          <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
            Get a key at{" "}
            <a
              href="https://platform.openai.com/api-keys"
              target="_blank"
              rel="noopener noreferrer"
              className="underline underline-offset-2"
            >
              platform.openai.com/api-keys
            </a>
            . The key is stored encrypted on this machine and never shared.
          </p>
        </div>

        {keyStatus?.set && (
          <div className="rounded-md border border-border bg-muted/40 px-4 py-2 text-sm">
            Current key: <span className="font-mono">{keyStatus.preview}</span>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="openai-key" className="text-sm font-medium">
            API Key
          </Label>
          <Input
            id="openai-key"
            type="password"
            autoFocus
            placeholder="sk-..."
            className="h-12 text-base"
            value={keyInput}
            data-testid="input-openai-key"
            onChange={(e) => setKeyInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && keyInput.trim()) saveKey.mutate();
            }}
          />
        </div>

        {message && (
          <p
            className="rounded-md border border-border bg-muted/40 px-4 py-3 text-sm"
            role="alert"
          >
            {message}
          </p>
        )}

        <div className="flex gap-2">
          <Button
            className="flex-1"
            disabled={!keyInput.trim() || saveKey.isPending}
            data-testid="button-save-ai-key"
            onClick={() => saveKey.mutate()}
          >
            {saveKey.isPending ? "Saving…" : "Save key"}
          </Button>
          {keyStatus?.set && (
            <Button
              variant="outline"
              disabled={saveKey.isPending}
              data-testid="button-clear-ai-key"
              onClick={() => {
                setKeyInput("");
                saveKey.mutate({ apiKey: "" } as any);
              }}
            >
              Clear
            </Button>
          )}
          <Button
            variant="ghost"
            onClick={() => {
              setExpanded(false);
              setKeyInput("");
              setMessage(null);
            }}
          >
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
