/**
 * License key middleware for Reindeer Registry.
 *
 * TOGGLED OFF — controlled by FEATURE_FLAGS.licenseKeys.
 * When enabled, this middleware validates the user's license key
 * and enforces read-only mode for lapsed subscriptions.
 * Currently passes all requests through (testing mode = unlimited access).
 *
 * To enable:
 *   1. Set FEATURE_FLAGS.licenseKeys = true in featureFlags.js
 *   2. Implement JWT validation logic below
 *   3. Mount this middleware after session attachment
 */

import { isLicenseEnforced } from './featureFlags.js';

/**
 * Returns true if the request has full read/write access.
 * When license enforcement is OFF (current state), always returns true.
 * When ON, checks the license_keys table for an active key.
 */
export function hasWriteAccess(req) {
  // Testing mode — everything is unlimited
  if (!isLicenseEnforced()) return true;

  // When enabled, check req.session for a valid license
  // const license = req.session?.license;
  // if (!license || license.status !== 'active') return false;
  // return true;

  return true; // Fallback: allow all (replace with real check when enabled)
}

/**
 * Returns true if the request has read access.
 * Read access is NEVER revoked — even lapsed subscriptions can read
 * and export their data. Data is never deleted for non-payment.
 */
export function hasReadAccess(_req) {
  return true; // Always true — reading is never blocked
}

/**
 * Express middleware: blocks write operations for lapsed licenses.
 * When license enforcement is OFF, this is a no-op.
 */
export function requireLicenseForWrite(req, res, next) {
  if (!isLicenseEnforced()) {
    return next(); // No-op in testing mode
  }

  if (!hasWriteAccess(req)) {
    return res.status(403).json({
      error: 'Your subscription has lapsed. Your data is safe — renew to continue adding.',
      read_only: true,
    });
  }

  next();
}
